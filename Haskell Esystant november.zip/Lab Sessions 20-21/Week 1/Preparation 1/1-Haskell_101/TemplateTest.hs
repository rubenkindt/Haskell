{-# LANGUAGE StandaloneDeriving  #-}
{-# LANGUAGE ScopedTypeVariables #-}

{-# OPTIONS_GHC -Wall #-}

module Main (main) where

import Template
import Testing

-- * Tests for double
-- ----------------------------------------------------------------------------

prop_double_1 :: Test
prop_double_1 = randomTest
                "forall x. double x = x + x"
                1
                (\x -> double x == x + x)

-- * Some more tests from the assignment pdf
-- ----------------------------------------------------------------------------

prop_double_2 :: Test
prop_double_2 = unitTest
                "double 3"
                (double 3)
                6

prop_double_3 :: Test
prop_double_3 = unitTest
                "double 21"
                (double 21)
                42

-- * Tests for myAbs
-- ----------------------------------------------------------------------------

prop_myabs_1 :: Test
prop_myabs_1 = randomTest
               "forall x. myAbs > 0"
               1
               (\x -> myAbs x >= 0)

-- * Some more tests from the assignment pdf
-- ----------------------------------------------------------------------------

prop_myabs_2 :: Test
prop_myabs_2 = unitTest
               "myAbs 0"
               (myAbs 0)
               0

prop_myabs_3 :: Test
prop_myabs_3 = unitTest
               "myAbs 42"
               (myAbs 42)
               42

prop_myabs_4 :: Test
prop_myabs_4 = unitTest
               "myAbs (-42)"
               (myAbs (-42))
               42

-- * Tests for toFahrenheit
-- ----------------------------------------------------------------------------

prop_toFahrenheit_1 :: Test
prop_toFahrenheit_1 = unitTest
                      "toFahrenheit 20.0"
                      (toFahrenheit 20.0)
                      68.0

prop_toFahrenheit_2 :: Test
prop_toFahrenheit_2 = unitTest
                      "toFahrenheit (-3.0)"
                      (toFahrenheit (-3.0))
                      26.6

-- * Tests for fizzbuzz
-- ----------------------------------------------------------------------------

prop_fizzbuzz_1 :: Test
prop_fizzbuzz_1 = unitTest
                  "fizzbuzz 2"
                  (fizzbuzz 2)
                  "2"

prop_fizzbuzz_2 :: Test
prop_fizzbuzz_2 = unitTest
                  "fizzbuzz 3"
                  (fizzbuzz 3)
                  "fizz"

prop_fizzbuzz_3 :: Test
prop_fizzbuzz_3 = unitTest
                  "fizzbuzz 4"
                  (fizzbuzz 4)
                  "4"

prop_fizzbuzz_4 :: Test
prop_fizzbuzz_4 = unitTest
                  "fizzbuzz 5"
                  (fizzbuzz 5)
                  "buzz"

prop_fizzbuzz_5 :: Test
prop_fizzbuzz_5 = unitTest
                  "fizzbuzz 15"
                  (fizzbuzz 15)
                  "fizzbuzz"

-- ----------------------------------------------------------------------------

-- All the tests to run
allTests :: [Test]
allTests = [ -- * Function double
             prop_double_1, prop_double_2, prop_double_3

             -- * Function myAbs
             -- --------------------------------------------------------------------------
           , prop_myabs_1, prop_myabs_2, prop_myabs_3, prop_myabs_4

             -- * Function toFahrenheit
             -- --------------------------------------------------------------------------
           , prop_toFahrenheit_1, prop_toFahrenheit_2

             -- * Function fizzbuzz
             -- --------------------------------------------------------------------------
           , prop_fizzbuzz_1, prop_fizzbuzz_2, prop_fizzbuzz_3
           , prop_fizzbuzz_4, prop_fizzbuzz_5
           ]


-- Default call
main :: IO ()
main = processSubmission allTests

-- -- Uncomment this if you want to check the tests locally, without colors
-- main :: IO ()
-- main = runAndPrintTestsLocally False allTests

-- -- Uncomment this if you want to check the tests locally, with colors enabled
-- main :: IO ()
-- main = runAndPrintTestsLocally True allTests
