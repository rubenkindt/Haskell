
module Template where

-- * Haskell 101
-- ----------------------------------------------------------------------------

double :: Int -> Int
double = error "Not implemented"

myAbs :: Int -> Int
myAbs = error "Not implemented"

toFahrenheit :: Float -> Float
toFahrenheit = error "Not implemented"

fizzbuzz :: Int -> String
fizzbuzz = error "Not implemented"

