{-# LANGUAGE StandaloneDeriving  #-}
{-# LANGUAGE ScopedTypeVariables #-}

{-# OPTIONS_GHC -Wall #-}

module Main (main) where

import Template
import Testing

-- * Tests for count
-- ----------------------------------------------------------------------------

-- count behaves the same as length
prop_count_1 :: Test
prop_count_1 = randomTest
               "forall xs. length xs == count xs"
               1
               (\xs -> length xs == count xs)

-- * Some more tests from the assignment pdf
-- ----------------------------------------------------------------------------

prop_count_2 :: Test
prop_count_2 = unitTest
               "count [1, 2, 3]"
               (count [1, 2, 3])
               3

prop_count_3 :: Test
prop_count_3 = unitTest
               "count []"
               (count [])
               0


-- * Tests for myAnd
-- ----------------------------------------------------------------------------

-- The result is False iff it contains at least one False
prop_and_1 :: Test
prop_and_1 = randomTest
               "forall xs. (myAnd xs == False) == elem False xs"
               1
               (\xs -> (myAnd xs == False) == elem False xs)

-- * Some more tests from the assignment pdf
-- ----------------------------------------------------------------------------

prop_and_2 :: Test
prop_and_2 = unitTest
               "myAnd [True, False]"
               (myAnd [True, False])
               False

prop_and_3 :: Test
prop_and_3 = unitTest
               "myAnd [True, True, True]"
               (myAnd [True, True, True])
               True

prop_and_4 :: Test
prop_and_4 = unitTest
               "myAnd []"
               (myAnd [])
               True

-- * Tests for myOr
-- ----------------------------------------------------------------------------

-- The result is True iff it contains at least one True
prop_or_1 :: Test
prop_or_1 = randomTest
               "forall xs. (myOr xs == True) == elem True xs"
               1
               (\xs -> (myOr xs == True) == elem True xs)

-- * Some more tests from the assignment pdf
-- ----------------------------------------------------------------------------

prop_or_2 :: Test
prop_or_2 = unitTest
              "myOr [True, False]"
              (myOr [True, False])
              True

prop_or_3 :: Test
prop_or_3 = unitTest
              "myOr [False, False, False, False]"
              (myOr [False, False, False, False])
              False

prop_or_4 :: Test
prop_or_4 = unitTest
              "myOr []"
              (myOr [])
              False

-- * Tests for append
-- ----------------------------------------------------------------------------

-- List concatenation is associative
prop_append_1 :: Test
prop_append_1 = randomTest
                  "forall xs ys zs. append xs (append ys zs) == append (append xs ys) zs"
                  3
                  (\xs ys zs -> append xs (append ys zs) == append (append xs ys) zs)

-- The empty list is left neutral
prop_append_2 :: Test
prop_append_2 = randomTest
                  "forall xs. append [] xs == xs"
                  1
                  (\xs -> append [] xs == xs)


-- The empty list is right neutral
prop_append_3 :: Test
prop_append_3 = randomTest
                  "forall xs. append xs [] == xs"
                  1
                  (\xs -> append xs [] == xs)

-- Appending lists preserves the first element
prop_append_4 :: Test
prop_append_4 = randomTest
                  "forall x xs ys. head (append (x:xs) ys) == x"
                  3
                  (\x xs ys -> head (append (x:xs) ys) == x)

-- Appending lists preserves the last element
prop_append_5 :: Test
prop_append_5 = randomTest
                  "forall x xs ys. last (append xs (ys ++ [x])) == x"
                  3
                  (\x xs ys -> last (append xs (ys ++ [x])) == x)

-- The length of the append list is the sum of the lengths of the input lists
prop_append_6 :: Test
prop_append_6 = randomTest
                  "forall xs ys. length (append xs ys) == length xs + length ys"
                  2
                  (\xs ys -> length (append xs ys) == length xs + length ys)

-- * Some more tests from the assignment pdf
-- ----------------------------------------------------------------------------

prop_append_7 :: Test
prop_append_7 = unitTest
                  "append [1,2] [3,4,5]"
                  (append [1,2] [3,4,5])
                  [1,2,3,4,5]

-- ----------------------------------------------------------------------------

-- All the tests to run
allTests :: [Test]
allTests = [ -- * Function count
             prop_count_1, prop_count_2, prop_count_3

             -- * Function myAnd
             -- --------------------------------------------------------------------------
           , prop_and_1, prop_and_2, prop_and_3, prop_and_4

             -- * Function myOr
             -- --------------------------------------------------------------------------
           , prop_or_1, prop_or_2, prop_or_3, prop_or_4

             -- * Function append
             -- --------------------------------------------------------------------------
           , prop_append_1, prop_append_2, prop_append_3
           , prop_append_4, prop_append_5, prop_append_6
           , prop_append_7
           ]


           -- Default call
main :: IO ()
main = processSubmission allTests

-- -- Uncomment this if you want to check the tests locally, without colors
-- main :: IO ()
-- main = runAndPrintTestsLocally False allTests

-- -- Uncomment this if you want to check the tests locally, with colors enabled
-- main :: IO ()
-- main = runAndPrintTestsLocally True allTests
