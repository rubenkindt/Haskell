
module Template where

-- * List Operations
-- ----------------------------------------------------------------------------

count :: [Int] -> Int
count = error "Not implemented"

myAnd :: [Bool] -> Bool
myAnd = error "Not implemented"

myOr :: [Bool] -> Bool
myOr = error "Not implemented"

append :: [Int] -> [Int] -> [Int]
append = error "Not implemented"

