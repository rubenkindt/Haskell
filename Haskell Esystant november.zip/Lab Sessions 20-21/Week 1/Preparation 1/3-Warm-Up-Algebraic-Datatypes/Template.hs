
module Template where

data Name = ReplaceMe1
    deriving (Show)

data Pair = ReplaceMe2
    deriving (Show)

data Gender = ReplaceMe3
    deriving (Show)

data Person = ReplaceMe4
    deriving (Show)

data TestResult = ReplaceMe5
    deriving (Show)


stringToGender :: String -> Gender
stringToGender = error "Not implemented"

genderToString :: Gender -> String
genderToString = error "Not implemented"


passing :: Int -> TestResult
passing = error "Not implemented"

failing :: [String] -> TestResult
failing = error "Not implemented"

grade :: TestResult -> Int
grade = error "Not implemented"

comments :: TestResult -> [String]
comments = error "Not implemented"
