{-# LANGUAGE DeriveDataTypeable #-}
{-# LANGUAGE ScopedTypeVariables #-}
{-# LANGUAGE StandaloneDeriving  #-}

{-# OPTIONS_GHC -Wall -fno-warn-orphans #-}

module Main (main) where

import Data.Data

import Template
import Testing hiding (TestResult)

-- * Tests for ADTs
-- ----------------------------------------------------------------------------
-- We use Data.Data to check the number of constructors.
--
-- Unfortunately, there no easy way to check the types of the fields of a
-- constructor.
--
deriving instance Data Name
deriving instance Data Pair
deriving instance Data Gender
deriving instance Data Person
deriving instance Data TestResult

prop_Name_Constructors :: Test
prop_Name_Constructors =
    unitTest
        "Name has the right number of constructors"
        (let constrs = map showConstr $ dataTypeConstrs $ dataTypeOf (undefined :: Name)
         in if constrs == ["ReplaceMe1"] then error "not-implemented" else length constrs)
        1

prop_Pair_Constructors :: Test
prop_Pair_Constructors =
    unitTest
        "Pair has the right number of constructors"
        (let constrs = map showConstr $ dataTypeConstrs $ dataTypeOf (undefined :: Pair)
         in if constrs == ["ReplaceMe2"] then error "not-implemented" else length constrs)
        1

prop_Gender_Constructors :: Test
prop_Gender_Constructors =
    unitTest
        "Gender has the right number of constructors"
        (let constrs = map showConstr $ dataTypeConstrs $ dataTypeOf (undefined :: Gender)
         in if constrs == ["ReplaceMe3"] then error "not-implemented" else length constrs)
        3

prop_Person_Constructors :: Test
prop_Person_Constructors =
    unitTest
        "Person has the right number of constructors"
        (let constrs = map showConstr $ dataTypeConstrs $ dataTypeOf (undefined :: Person)
         in if constrs == ["ReplaceMe4"] then error "not-implemented" else length constrs)
        1

prop_TestResult_Constructors :: Test
prop_TestResult_Constructors =
    unitTest
        "TestResult has the right number of constructors"
        (let constrs = map showConstr $ dataTypeConstrs $ dataTypeOf (undefined :: TestResult)
         in if constrs == ["ReplaceMe5"] then error "not-implemented" else length constrs)
        2

-- * Tests for stringToGender and genderToString
-- ----------------------------------------------------------------------------

prop_stringToGender_genderToString_1 :: Test
prop_stringToGender_genderToString_1 =
    unitTest
        "genderToString (stringToGender \"Male\")"
        (genderToString (stringToGender "Male"))
        "Male"

prop_stringToGender_genderToString_2 :: Test
prop_stringToGender_genderToString_2 =
    unitTest
        "genderToString (stringToGender \"Female\")"
        (genderToString (stringToGender "Female"))
        "Female"

prop_stringToGender_genderToString_3 :: Test
prop_stringToGender_genderToString_3 =
    unitTest
        "genderToString (stringToGender \"Hamster\")"
        (genderToString (stringToGender "Hamster"))
        "Other"

prop_stringToGender_genderToString_4 :: Test
prop_stringToGender_genderToString_4 =
    unitTest
        "genderToString (stringToGender \"\")"
        (genderToString (stringToGender ""))
        "Other"

prop_stringToGender_genderToString_5 :: Test
prop_stringToGender_genderToString_5 =
    unitTest
        "genderToString (stringToGender \"DT\")"
        (genderToString (stringToGender "DT"))
        "Other"


-- * Tests for grade, comments, passing, failing
-- ----------------------------------------------------------------------------

prop_grade_passing_1 :: Test
prop_grade_passing_1 =
    randomTest
        "forall x. grade (passing x) == x"
        1
        (\x -> grade (passing x) == x)

prop_grade_passing_2 :: Test
prop_grade_passing_2 =
    unitTest
        "grade (passing 10)"
        (grade (passing 10))
        10

prop_grade_failing_1 :: Test
prop_grade_failing_1 =
    randomTest
        "forall cs. grade (failing cs) == 0"
        1
        (\cs -> grade (failing cs) == 0)

prop_grade_failing_2 :: Test
prop_grade_failing_2 =
    unitTest
        "grade (failing [\"Incorrect datatype syntax\"])"
        (grade (failing ["Incorrect datatype syntax"]))
        0

prop_comments_passing_1 :: Test
prop_comments_passing_1 =
    randomTest
        "forall x. comments (passing x) == []"
        1
        (\x -> comments (passing x) == [])

prop_comments_passing_2 :: Test
prop_comments_passing_2 =
    unitTest
        "comments (passing 10)"
        (comments (passing 10))
        []

prop_comments_failing_1 :: Test
prop_comments_failing_1 =
    randomTest
        "forall cs. comments (failing cs) == cs"
        1
        (\cs -> comments (failing cs) == cs)

prop_comments_failing_2 :: Test
prop_comments_failing_2 =
    unitTest
        "comments (failing [\"Incorrect datatype syntax\"])"
        (comments (failing ["Incorrect datatype syntax"]))
        ["Incorrect datatype syntax"]



-- All the tests to run
allTests :: [Test]
allTests = [ -- * ADT constructors
             -- --------------------------------------------------------------------------
             prop_Name_Constructors
           , prop_Pair_Constructors
           , prop_Gender_Constructors
           , prop_Person_Constructors
           , prop_TestResult_Constructors

             -- * stringToGender and genderToString
             -- --------------------------------------------------------------------------
           , prop_stringToGender_genderToString_1
           , prop_stringToGender_genderToString_2
           , prop_stringToGender_genderToString_3
           , prop_stringToGender_genderToString_4
           , prop_stringToGender_genderToString_5

             -- * grade, comments, passing, failing
             -- --------------------------------------------------------------------------
           , prop_grade_passing_1
           , prop_grade_passing_2
           , prop_grade_failing_1
           , prop_grade_failing_2
           , prop_comments_passing_1
           , prop_comments_passing_2
           , prop_comments_failing_1
           , prop_comments_failing_2

           ]

-- Default call
main :: IO ()
main = processSubmission allTests

-- -- Uncomment this if you want to check the tests locally, without colors
-- main :: IO ()
-- main = runAndPrintTestsLocally False allTests

-- -- Uncomment this if you want to check the tests locally, with colors enabled
-- main :: IO ()
-- main = runAndPrintTestsLocally True allTests
