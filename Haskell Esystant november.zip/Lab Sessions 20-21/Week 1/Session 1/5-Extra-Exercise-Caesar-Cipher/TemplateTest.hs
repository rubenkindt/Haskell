{-# LANGUAGE StandaloneDeriving  #-}
{-# LANGUAGE ScopedTypeVariables #-}

{-# OPTIONS_GHC -Wall #-}

module Main (main) where

import Template
import Testing
import Data.List (isSuffixOf, isPrefixOf)

-- * Tests for shift
-- ----------------------------------------------------------------------------

-- Exhaustive test that (shift n) == (shift (n-26))
prop_shift_1 :: Test
prop_shift_1 = unitTest
                 "and [ shift n c == shift (n-26) c | n <- [0..25], c <- [\'a\'..\'z\'] ]"
                 (and [ shift n c == shift (n-26) c | n <- [0..25], c <- ['a'..'z'] ])
                 True

-- Unfortunately, function `isLower` is really unsafe. It gives true for more
-- things than the simple lowercase letters (some non-printable characters).
-- Omit this test.
--
-- -- All characters above the range should remain unchanged
-- prop_shift_6 :: Test
-- prop_shift_6 = randomTest
--                  "forall n c. (c > \'z\') ==> (shift n c == c)"
--                  2
--                  (\n c -> (c > 'z') ==> (shift n c == c))

-- All characters below the range should remain unchanged
prop_shift_2 :: Test
prop_shift_2 = randomTest
                 "forall n c. (c < \'a\') ==> (shift n c == c)"
                 2
                 (\n c -> (c < 'a') ==> (shift n c == c))

-- * Some more tests from the assignment pdf
-- ----------------------------------------------------------------------------

prop_shift_3 :: Test
prop_shift_3 = unitTest
                 "shift 3 \'a\'"
                 (shift 3 'a')
                 'd'

prop_shift_4 :: Test
prop_shift_4 = unitTest
                 "shift 3 \'z\'"
                 (shift 3 'z')
                 'c'

prop_shift_5 :: Test
prop_shift_5 = unitTest
                 "shift (-3) \'c\'"
                 (shift (-3) 'c')
                 'z'

prop_shift_6 :: Test
prop_shift_6 = unitTest
                 "shift 3 \' \'"
                 (shift 3 ' ')
                 ' '

-- * Tests for encode
-- ----------------------------------------------------------------------------

-- We are on the modulo ring
prop_encode_1 :: Test
prop_encode_1 = randomTest
                  "forall n m s. encode n (encode m s) == encode (n + m) s"
                  3
                  (\n m s -> encode n (encode m s) == encode (n + m) s)

-- Encode with n and consecutively with (-n) gives back the input (positive first)
prop_encode_2 :: Test
prop_encode_2 = randomTest
                  "forall n. (n >= 0) ==> encode (-n) (encode n ([\'a\'..\'z\'] ++ \"~!@#$%^&*() _\")) == ([\'a\'..\'z\'] ++ \"~!@#$%^&*() _\")"
                  1
                  (\n -> (n >= 0) ==> encode (-n) (encode n (['a'..'z'] ++ "~!@#$%^&*() _")) == (['a'..'z'] ++ "~!@#$%^&*() _"))

-- Encode with n and consecutively with (-n) gives back the input (negative first)
prop_encode_3 :: Test
prop_encode_3 = randomTest
                  "forall n. (n >= 0) ==> encode n (encode (-n) ([\'a\'..\'z\'] ++ \"~!@#$%^&*() _\")) == ([\'a\'..\'z\'] ++ \"~!@#$%^&*() _\")"
                  1
                  (\n -> (n >= 0) ==> encode n (encode (-n) (['a'..'z'] ++ "~!@#$%^&*() _")) == (['a'..'z'] ++ "~!@#$%^&*() _"))

-- * Some more tests from the assignment pdf
-- ----------------------------------------------------------------------------

prop_encode_4 :: Test
prop_encode_4 = unitTest
                  "encode 3 \"haskell is fun\""
                  (encode 3 "haskell is fun")
                  "kdvnhoo lv ixq"

prop_encode_5 :: Test
prop_encode_5 = unitTest
                  "encode (-3) \"kdvnhoo lv ixq\""
                  (encode (-3) "kdvnhoo lv ixq")
                  "haskell is fun"

-- * Tests for percent
-- ----------------------------------------------------------------------------

-- The basic property, derived from the definition
prop_percent_1 :: Test
prop_percent_1 = randomTest
                   "forall n m. (n > 0 && m > 0) ==> abs ((percent n m * fromIntegral m) / 100 - fromIntegral n) < 0.00001"
                   2
                   (\n m -> (n > 0 && m > 0) ==> abs ((percent n m * fromIntegral m) / 100 - fromIntegral n) < 0.00001)

-- * Some more tests from the assignment pdf
-- ----------------------------------------------------------------------------

prop_percent_2 :: Test
prop_percent_2 = unitTest
                   "percent 6 12"
                   (percent 6 12)
                   50.0

prop_percent_3 :: Test
prop_percent_3 = unitTest
                   "percent 3 15"
                   (percent 3 15)
                   20.0

-- * Tests for freqs
-- ----------------------------------------------------------------------------

prop_freqs_1 :: Test
prop_freqs_1 = randomTest
                 "forall n. n > 0 ==> and [ freqs (replicate n c) !! let2int c == 100 |  c <- [\'a\'..\'z\'] ]"
                 1
                 (\n -> n > 0 ==> and [ freqs (replicate n c) !! let2int c == 100 |  c <- ['a'..'z'] ])

-- * Some more tests from the assignment pdf
-- ----------------------------------------------------------------------------

prop_freqs_2 :: Test
prop_freqs_2 = unitTest
                 "freqs \"abbcccdddeedeee\" = [ 6.666667,13.333334,20.0,26.666668,33.333336,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0 ]"
                 (foldr (\(x,y) b -> b && abs (x-y) < 0.0001) True (zip (freqs "abbcccdddeedeee") [ 6.666667,13.333334,20.0,26.666668,33.333336,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0 ] ) )
                 -- [ 6.7, 13.3, 20.0, 26.7, 33.3, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0 ]
                 True
-- We should actually ask for a result with respect to a possible (absolute) deviation 0.000001 or something
-- This doesn't make the test any more readable though...

-- * Tests for chisqr
-- ----------------------------------------------------------------------------

prop_chisqr_1 :: Test
prop_chisqr_1 = randomTest
                  "forall n. chisqr [1..n] [1..n] == 0.0"
                  1
                  (\n -> chisqr [1..n] [1..n] == 0.0)


-- -- God I hate floating point numbers
-- prop_chisqr_2 :: Test
-- prop_chisqr_2 = randomTest
--                   "forall n. n > 0 ==> chisqr (map fromIntegral [1..n]) (replicate n (fromIntegral n)) == sum (map (fromIntegral . (^2)) [1..n-1]) / fromIntegral n)"
--                   1
--                   (\n -> n > 0 ==> abs (chisqr (map fromIntegral [1..n]) (replicate n (fromIntegral n)) - sum (map (fromIntegral . (^(2 :: Int))) [1..n-1]) / fromIntegral n) < 0.0001)


-- * Some more tests from the assignment pdf
-- ----------------------------------------------------------------------------

-- * Tests for rotate
-- ----------------------------------------------------------------------------

-- Rotating by the length of the input should be the identity
prop_rotate_1 :: Test
prop_rotate_1 = randomTest
                  "forall xs. rotate (length xs) xs == xs"
                  1
                  (\(xs :: [Int]) -> rotate (length xs) xs == xs)

-- Rotating by zero should be the identity
prop_rotate_2 :: Test
prop_rotate_2 = randomTest
                  "forall xs. rotate 0 xs == xs"
                  1
                  (\(xs :: [Int]) -> rotate 0 xs == xs)

-- Suffix property
prop_rotate_3 :: Test
prop_rotate_3 = randomTest
                  "forall xs. and [ isSuffixOf (take (length xs - n) (rotate n xs)) xs | n <- [0..length xs] ]"
                  1
                  (\(xs :: [Int]) -> and [ isSuffixOf (take (length xs - n) (rotate n xs)) xs | n <- [0..length xs] ])

-- Prefix property
prop_rotate_4 :: Test
prop_rotate_4 = randomTest
                  "forall xs. and [ isPrefixOf (drop (length xs - n) (rotate n xs)) xs | n <- [0..length xs] ]"
                  1
                  (\(xs :: [Int]) -> and [ isPrefixOf (drop (length xs - n) (rotate n xs)) xs | n <- [0..length xs] ])

-- No matter the rotation, length should be preserved
prop_rotate_5 :: Test
prop_rotate_5 = randomTest
                  "forall xs. and [ length (rotate n xs) == length xs | n <- [0..length xs] ]"
                  1
                  (\(xs :: [Int]) -> and [ length (rotate n xs) == length xs | n <- [0..length xs] ])

-- * Some more tests from the assignment pdf
-- ----------------------------------------------------------------------------

prop_rotate_6 :: Test
prop_rotate_6 = unitTest
                  "rotate 3 [1,2,3,4,5]"
                  (rotate 3 [1,2,3,4,5])
                  [4,5,1,2,3 :: Int]

-- * Tests for crack
-- ----------------------------------------------------------------------------
-- The unit tests seem to suffice for this one

-- * Some more tests from the assignment pdf
-- ----------------------------------------------------------------------------

prop_crack_1 :: Test
prop_crack_1 = unitTest
                 "crack \"kdvnhoo lv ixq\""
                 (crack "kdvnhoo lv ixq")
                 "haskell is fun"

prop_crack_2 :: Test
prop_crack_2 = unitTest
                 "crack \"vscd mywzboroxcsyxc kbo ecopev\""
                 (crack "vscd mywzboroxcsyxc kbo ecopev")
                 "list comprehensions are useful"

prop_crack_3 :: Test
prop_crack_3 = unitTest
                 "crack (encode 3 \"haskell\")"
                 (crack (encode 3 "haskell"))
                 "piasmtt"

prop_crack_4 :: Test
prop_crack_4 = unitTest
                 "crack (encode 3 \"boxing wizards jump quickly\")"
                 (crack (encode 3 "boxing wizards jump quickly"))
                 "wjsdib rduvmyn ephk lpdxfgt"

-- All the tests to run
allTests :: [Test]
allTests = [ -- * shift
             prop_shift_1, prop_shift_2
           , prop_shift_3, prop_shift_4, prop_shift_5, prop_shift_6
             -- * encode
           , prop_encode_1, prop_encode_2, prop_encode_3
           , prop_encode_4, prop_encode_5
             -- * percent
           , prop_percent_1, prop_percent_2, prop_percent_3
             -- * freqs
           , prop_freqs_1, prop_freqs_2
             -- * chisqr
           , prop_chisqr_1 -- , prop_chisqr_2
             -- * rotate
           , prop_rotate_1, prop_rotate_2, prop_rotate_3, prop_rotate_4, prop_rotate_5
           , prop_rotate_6
             -- * crack
           , prop_crack_1, prop_crack_2, prop_crack_3, prop_crack_4
           ]

-- Default call
main :: IO ()
main = runAndPrintTestsJSON allTests

-- -- Uncomment this if you want to check the tests locally, without colors
-- main :: IO ()
-- main = runAndPrintTestsLocally False allTests

-- -- Uncomment this if you want to check the tests locally, with colors enabled
-- main :: IO ()
-- main = runAndPrintTestsLocally True allTests

