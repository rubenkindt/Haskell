
module Template where

-- * List Operations
-- ----------------------------------------------------------------------------

factorial :: Integer -> Integer
factorial = error "Not implemented"

myRepeat :: Int -> Int -> [Int]
myRepeat n x = error "Not implemented"

flatten :: [[Int]] -> [Int]
flatten list = error "Not implemented"

range :: Int -> Int -> [Int]
range low high = error "Not implemented"

sumInts :: Int -> Int -> Int
sumInts = error "Not implemented"

removeMultiples :: Int -> [Int] -> [Int]
removeMultiples = error "Not implemented"

