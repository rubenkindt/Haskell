{-# LANGUAGE StandaloneDeriving  #-}
{-# LANGUAGE ScopedTypeVariables #-}

{-# OPTIONS_GHC -Wall -fno-warn-orphans #-}

module Main (main) where

import Template
import Testing hiding (Result)

-- * Interface to the students' code
-- ----------------------------------------------------------------------------

deriving instance Bounded Move
deriving instance Enum Move

allMoves :: [Move]
allMoves = [minBound .. maxBound]

deriving instance Bounded Result
deriving instance Enum Result

allResults :: [Result]
allResults = [minBound .. maxBound]

instance Arbitrary Move where
  arbitrary = oneof $ map return allMoves

instance Arbitrary Result where
  arbitrary = oneof $ map return allResults

-- * Tests for unpair
-- ----------------------------------------------------------------------------

-- Check that the datatype "Move" has 3 constructors
prop_three_cons_1 :: Test
prop_three_cons_1 = unitTest
                      "Datatype Move should have 3 constructors"
                      (length allMoves)
                      3

-- Check that the datatype "Result" has 3 constructors
prop_three_cons_2 :: Test
prop_three_cons_2 = unitTest
                      "Datatype Result should have 3 constructors"
                      (length allResults)
                      3

-- No move can be beaten by itself
prop_no_beat_thyself_1 :: Test
prop_no_beat_thyself_1 = randomTest
                           "forall m. beat m /= m"
                           1
                           (\m -> beat m /= m)

-- No move can beat itself
prop_no_beat_thyself_2 :: Test
prop_no_beat_thyself_2 = randomTest
                           "forall m. lose m /= m"
                           1
                           (\m -> lose m /= m)

-- The one who beats the one I can beat is me
prop_beat_lose_1 :: Test
prop_beat_lose_1 = randomTest
                   "forall m. beat (lose m) == m"
                   1
                   (\m -> beat (lose m) == m)

-- The one who loses against the one who can beat me is me
prop_beat_lose_2 :: Test
prop_beat_lose_2 = randomTest
                     "forall m. lose (beat m) == m"
                     1
                     (\m -> lose (beat m) == m)

-- Applying beat three times gives the identity (circular wins)
prop_beat_three :: Test
prop_beat_three = randomTest
                    "forall m. beat (beat (beat m)) == m"
                    1
                    (\m -> beat (beat (beat m)) == m)

-- Applying lose three times gives the identity (circular losses)
prop_lose_three :: Test
prop_lose_three = randomTest
                    "forall m. lose (lose (lose m)) = m"
                    1
                    (\m -> lose (lose (lose m)) == m)

-- Function beat is injective
prop_beat_injective :: Test
prop_beat_injective = randomTest
                        "forall m n. (beat m == beat n) ==> (m == n)"
                        2
                        (\m n -> (beat m == beat n) ==> (m == n))

-- Function lose is injective
prop_lose_injective :: Test
prop_lose_injective = randomTest
                        "forall m n. (lose m == lose n) ==> (m == n)"
                        2
                        (\m n -> (lose m == lose n) ==> (m == n))

-- All the tests to run
allTests :: [Test]
allTests = [ -- * Exercise 2 (Rock - Paper - Scissors)
             -- --------------------------------------------------------------------------
             prop_three_cons_1
           , prop_no_beat_thyself_1, prop_no_beat_thyself_2
           , prop_beat_lose_1, prop_beat_lose_2
           , prop_beat_three, prop_lose_three
           , prop_three_cons_2
           , prop_beat_injective, prop_lose_injective
           ]

-- Default call
main :: IO ()
main = processSubmission allTests

-- -- Uncomment this if you want to check the tests locally, without colors
-- main :: IO ()
-- main = runAndPrintTestsLocally False allTests

-- -- Uncomment this if you want to check the tests locally, with colors enabled
-- main :: IO ()
-- main = runAndPrintTestsLocally True allTests

