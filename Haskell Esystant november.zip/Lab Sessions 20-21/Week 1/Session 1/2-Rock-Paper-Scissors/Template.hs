
module Template where

-- * Rock - Paper - Scissors
-- ----------------------------------------------------------------------------

data Move = DEFINE_POSSIBLE_MOVES
  deriving (Eq, Show)

beat :: Move -> Move
beat = error "Not implemented"

lose :: Move -> Move
lose = error "Not implemented"

data Result = DEFINE_POSSIBLE_RESULTS
  deriving (Eq, Show)

outcome :: Move -> Move -> Result
outcome = error "Not implemented"

