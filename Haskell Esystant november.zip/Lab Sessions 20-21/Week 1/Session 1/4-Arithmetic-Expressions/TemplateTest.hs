{-# LANGUAGE StandaloneDeriving  #-}
{-# LANGUAGE ScopedTypeVariables #-}

{-# OPTIONS_GHC -Wall -fno-warn-orphans #-}

module Main (main) where

import Template
import Testing
import Control.Monad (liftM, liftM2)

-- * Make Exp an instance of Arbitrary
-- ----------------------------------------------------------------------------

instance Arbitrary Exp where
  arbitrary =
    let exp' :: Int -> Gen Exp
        exp' 0 = liftM Const arbitrary
        exp' n | n > 0
               = oneof $ liftM Const arbitrary
                       : [ liftM2 i (exp' (n `div` 2)) (exp' (n `div` 2)) | i <- [Add,Sub,Mul] ]
               | otherwise = error "can't happen"
    in sized exp'

-- * Tests for eval
-- ----------------------------------------------------------------------------

-- Addition is associative
prop_eval_1 :: Test
prop_eval_1 = randomTest
                "forall e1 e2. eval (Add e1 e2) == eval (Add e2 e1)"
                2
                (\e1 e2 -> eval (Add e1 e2) == eval (Add e2 e1))


-- Multiplication is associative
prop_eval_2 :: Test
prop_eval_2 = randomTest
                "forall e1 e2. eval (Mul e1 e2) == eval (Mul e2 e1)"
                2
                (\e1 e2 -> eval (Mul e1 e2) == eval (Mul e2 e1))

-- Zero is left-neutral for addition
prop_eval_3 :: Test
prop_eval_3 = randomTest
                "forall e. eval (Add (Const 0) e) == eval e"
                1
                (\e -> eval (Add (Const 0) e) == eval e)

-- Anything multiplied by zero results in zero
prop_eval_4 :: Test
prop_eval_4 = randomTest
                "forall e. eval (Mul (Const 0) e) == 0"
                1
                (\e -> eval (Mul (Const 0) e) == 0)

-- The only way for (e1-e2) to be equal to (e2-e1) is if e1==e2 (i.e. e1-e2 == e2-e1 == 0)
prop_eval_5 :: Test
prop_eval_5 = randomTest
                "forall e1 e2. (eval (Sub e1 e2) /= eval (Sub e2 e1)) ==> (eval e1 /= eval e2)"
                2
                (\e1 e2 -> (eval (Sub e1 e2) /= eval (Sub e2 e1)) ==> (eval e1 /= eval e2))

-- Subtracting a negative is like adding its absolute value
prop_eval_6 :: Test
prop_eval_6 = randomTest
                "forall e1. (eval e >= 0) ==> (eval (Sub e (Const (-1))) == eval (Add e (Const 1)))"
                1
                (\e -> (eval e >= 0) ==> (eval (Sub e (Const (-1))) == eval (Add e (Const 1))))

-- Just a unit test
prop_eval_7 :: Test
prop_eval_7 = unitTest
                "eval (Sub (Const (-10)) (Const 5))"
                (eval (Sub (Const (-10)) (Const 5)))
                (-15)

-- * Some more tests from the assignment pdf
-- ----------------------------------------------------------------------------

prop_eval_8 :: Test
prop_eval_8 = unitTest
                "eval (Add (Mul (Const 2) (Const 4)) (Const 3))"
                (eval (Add (Mul (Const 2) (Const 4)) (Const 3)))
                11

prop_eval_9 :: Test
prop_eval_9 = unitTest
                "eval (Sub (Const 42) (Mul (Const 6) (Const 7)))"
                (eval (Sub (Const 42) (Mul (Const 6) (Const 7))))
                0

-- * Make Inst an instance of Arbitrary
-- ----------------------------------------------------------------------------

instance Arbitrary Inst where
  arbitrary = oneof [ liftM IPush arbitrary
                    , return IAdd
                    , return ISub
                    , return IMul ]

-- * Tests for execute
-- ----------------------------------------------------------------------------

-- Execution of IPush increases the length by one
prop_execute_1 :: Test
prop_execute_1 = randomTest
                   "forall n s. length (IPush n s) == length s + 1"
                   2
                   (\n s -> length (execute (IPush n) s) == length s + 1)

-- Execution of IAdd decreases the length by one
prop_execute_2 :: Test
prop_execute_2 = randomTest
                   "forall s. (length s >= 2) ==> (length (execute IAdd s) == (length s - 1))"
                   1
                   (\s -> (length s >= 2) ==> (length (execute IAdd s) == (length s - 1)))

-- Execution of IMul decreases the length by one
prop_execute_3 :: Test
prop_execute_3 = randomTest
                   "forall s. (length s >= 2) ==> (length (execute IMul s) == (length s - 1))"
                   1
                   (\s -> (length s >= 2) ==> (length (execute IMul s) == (length s - 1)))

-- Execution of ISub decreases the length by one
prop_execute_4 :: Test
prop_execute_4 = randomTest
                   "forall s. (length s >= 2) ==> (length (execute ISub s) == (length s - 1))"
                   1
                   (\s -> (length s >= 2) ==> (length (execute ISub s) == (length s - 1)))


-- * Some more tests for execute from the assignment pdf
-- ----------------------------------------------------------------------------

prop_execute_5 :: Test
prop_execute_5 = unitTest
                   "execute IAdd [4,5,6]"
                   (execute IAdd [4,5,6])
                   [9,6]

prop_execute_6 :: Test
prop_execute_6 = unitTest
                   "execute ISub [4,5,6]"
                   (execute ISub [4,5,6])
                   [1,6]

prop_execute_7 :: Test
prop_execute_7 = unitTest
                   "execute (IPush 2) [4,5,6]"
                   (execute (IPush 2) [4,5,6])
                   [2,4,5,6]


-- * Some unit tests for run from the assignment pdf
-- ----------------------------------------------------------------------------

prop_run_1 :: Test
prop_run_1 = unitTest
               "run [IAdd, ISub] [4,5,6]"
               (run [IAdd, ISub] [4,5,6])
               [-3]

prop_run_2 :: Test
prop_run_2 = unitTest
               "run [IAdd, ISub, IPush 7, IMul] [4,5,6,8]"
               (run [IAdd, ISub, IPush 7, IMul] [4,5,6,8])
               [-21,8]

prop_run_3 :: Test
prop_run_3 = unitTest
               "run [IPush 1,IPush 2,IPush 3,IMul,ISub] []"
               (run [IPush 1,IPush 2,IPush 3,IMul,ISub] [])
               [-5]

-- * Some unit tests for compile from the assignment pdf
-- ----------------------------------------------------------------------------

prop_compile_1 :: Test
prop_compile_1 = unitTest
                   "compile (Sub (Const 1) (Mul (Const 2) (Const 3)))"
                   (compile (Sub (Const 1) (Mul (Const 2) (Const 3))))
                   [IPush 1,IPush 2,IPush 3,IMul,ISub]

-- * Tests for run and compile (simultaneously)
-- ----------------------------------------------------------------------------

-- Main correctness theorem
prop_run_compile_1 :: Test
prop_run_compile_1 = randomTest
                       "forall e s. run (compile e) s == eval e : s"
                       2
                       (\e s -> run (compile e) s == eval e : s)

-- Same as above but fix the initial stack to [] for better coverage
prop_run_compile_2 :: Test
prop_run_compile_2 = randomTest
                       "forall e. run (compile e) [] == [eval e]"
                       1
                       (\e -> run (compile e) [] == [eval e])

-- All the tests to run
allTests :: [Test]
allTests = [ -- * Function eval
             -- --------------------------------------------------------------------------
             prop_eval_1, prop_eval_2, prop_eval_3, prop_eval_4, prop_eval_5
           , prop_eval_6, prop_eval_7, prop_eval_8, prop_eval_9

             -- * Function execute
             -- --------------------------------------------------------------------------
           , prop_execute_1, prop_execute_2, prop_execute_3, prop_execute_4
           , prop_execute_5, prop_execute_6, prop_execute_7

             -- * Function run
             -- --------------------------------------------------------------------------
           , prop_run_1, prop_run_2, prop_run_3

             -- * Function run
             -- --------------------------------------------------------------------------
           , prop_compile_1

             -- * Functions run and compile
             -- --------------------------------------------------------------------------
           , prop_run_compile_1, prop_run_compile_2

           ]

-- Default call
main :: IO ()
main = processSubmission allTests

-- -- Uncomment this if you want to check the tests locally, without colors
-- main :: IO ()
-- main = runAndPrintTestsLocally False allTests

-- -- Uncomment this if you want to check the tests locally, with colors enabled
-- main :: IO ()
-- main = runAndPrintTestsLocally True allTests

