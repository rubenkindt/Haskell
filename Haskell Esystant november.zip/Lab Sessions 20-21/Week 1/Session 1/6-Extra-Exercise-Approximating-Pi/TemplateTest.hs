{-# LANGUAGE StandaloneDeriving  #-}
{-# LANGUAGE ScopedTypeVariables #-}

{-# OPTIONS_GHC -Wall #-}

module Main (main) where

import Template
import Testing

i2f :: Int -> Float
i2f = fromIntegral


-- * Tests for sumf
-- ----------------------------------------------------------------------------

-- Gauss' sum
prop_sumf_1 :: Test
prop_sumf_1 = randomTest
                "forall n. sumf [1..n] == (n*(n+1)/2)"
                1
                (\(n :: Int) -> (n > 0) ==>
                                  let nf = fromIntegral n
                                  in  sumf (map fromIntegral [1..n]) == (nf*(nf+1)/2))

-- If we replicate n times x, then the sum of the list is n*x.
prop_sumf_2 :: Test
prop_sumf_2 = randomTest
                "forall n x. (n >= 0) ==> sumf (replicate n (fromIntegral x)) == fromIntegral n * fromIntegral x"
                2
                (\n (x :: Int) -> (n >= 0) ==> sumf (replicate n (fromIntegral x)) == fromIntegral n * fromIntegral x)

-- * Some more tests from the assignment pdf
-- ----------------------------------------------------------------------------

prop_sumf_3 :: Test
prop_sumf_3 = unitTest
                "sumf []"
                (sumf [])
                0.0

prop_sumf_4 :: Test
prop_sumf_4 = unitTest
                "sumf [1, 5.0, 6.32]"
                (sumf [1, 5.0, 6.32])
                12.32

-- * Some tests for productf from the assignment pdf
-- ----------------------------------------------------------------------------

prop_productf_1 :: Test
prop_productf_1 = unitTest
                    "productf []"
                    (productf [])
                    1.0

prop_productf_2 :: Test
prop_productf_2 = unitTest
                    "productf [1, 5.0, 6.32]"
                    (productf [1, 5.0, 6.32])
                    31.6

-- * Tests for piSum
-- ----------------------------------------------------------------------------

-- The higher the n, the higher the number gets (not strictly)
prop_pisum_1 :: Test
prop_pisum_1 = randomTest
                 "forall n m. (n > 0) && (m > n) ==> piSum m >= piSum n"
                 2
                 (\n m -> (n > 0) && (m > n) ==> piSum (i2f m) >= piSum (i2f n))

-- It is an increasing (not strictly) under-approximation of pi
prop_pisum_2 :: Test
prop_pisum_2 = randomTest
                 "forall n m. (n > 0) && (m > n) ==> abs (pi - piSum m) <= abs (pi - piSum n)"
                 2
                 (\n m -> (n > 0) && (m > n) ==> (pi - piSum (i2f m)) <= (pi - piSum (i2f n)))

-- * Some more tests from the assignment pdf
-- ----------------------------------------------------------------------------

prop_pisum_3 :: Test
prop_pisum_3 = unitTest
                 "piSum 0"
                 (piSum 0)
                 2.6666667

prop_pisum_4 :: Test
prop_pisum_4 = unitTest
                 "piSum 1"
                 (piSum 1)
                 2.8952382

prop_pisum_5 :: Test
prop_pisum_5 = unitTest
                 "piSum 2"
                 (piSum 2)
                 2.9760463

prop_pisum_6 :: Test
prop_pisum_6 = unitTest
                 "abs (3.1366422 - piSum 100) < 0.000001"
                 (abs (3.1366422 - piSum 100) < 0.000001)
                 True

-- * Tests for piProd
-- ----------------------------------------------------------------------------

-- The higher the n, the lower number gets (not strictly)
prop_piprod_1 :: Test
prop_piprod_1 = randomTest
                  "forall n m. (n > 0) && (m > n) ==> piProd m <= piProd n"
                  2
                  (\n m -> (n > 0) && (m > n) ==> piProd (i2f m) <= piProd (i2f n))

-- It is a decreasing (not strictly) over-approximation of pi
prop_piprod_2 :: Test
prop_piprod_2 = randomTest
                  "forall n m. (n > 0) && (m > n) ==> (piProd m - pi) <= (piProd n - pi)"
                  2
                  (\n m -> (n > 0) && (m > n) ==> (piProd (i2f m) - pi) <= (piProd (i2f n) - pi))

-- A simple unit test
prop_piprod_3 :: Test
prop_piprod_3 = unitTest
                  "piProd 0"
                  (piProd 0)
                  3.5555556

-- A simple unit test
prop_piprod_4 :: Test
prop_piprod_4 = unitTest
                  "piProd 1"
                  (piProd 1)
                  3.4133332

-- A simple unit test
prop_piprod_5 :: Test
prop_piprod_5 = unitTest
                  "piProd 2"
                  (piProd 2)
                  3.3436735

-- A simple unit test
prop_piprod_6 :: Test
prop_piprod_6 = unitTest
                  "abs (3.1493013 - piProd 100) < 0.000001"
                  (abs (3.1493013 - piProd 100) < 0.000001)
                  True

-- All the tests to run
allTests :: [Test]
allTests = [ -- * Function sumf
             -- --------------------------------------------------------------------------
             prop_sumf_1, prop_sumf_2 -- TODO: Add more tests
           , prop_sumf_3, prop_sumf_4

             -- * Function productf
             -- --------------------------------------------------------------------------
           , prop_productf_1, prop_productf_2 -- TODO: Add more tests

             -- * Function piSum
             -- --------------------------------------------------------------------------
           , prop_pisum_1, prop_pisum_2
           , prop_pisum_3, prop_pisum_4, prop_pisum_5, prop_pisum_6

             -- * Function piProd
             -- --------------------------------------------------------------------------
           , prop_piprod_1, prop_piprod_2
           , prop_piprod_3, prop_piprod_4, prop_piprod_5, prop_piprod_6

           ]
-- Default call
main :: IO ()
main = processSubmission allTests

-- -- Uncomment this if you want to check the tests locally, without colors
-- main :: IO ()
-- main = runAndPrintTestsLocally False allTests

-- -- Uncomment this if you want to check the tests locally, with colors enabled
-- main :: IO ()
-- main = runAndPrintTestsLocally True allTests

