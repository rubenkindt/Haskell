{-# LANGUAGE StandaloneDeriving  #-}
{-# LANGUAGE ScopedTypeVariables #-}

{-# OPTIONS_GHC -Wall #-}

module Main (main) where

import Template
import Testing

-- * Tests for sieve
-- ----------------------------------------------------------------------------

-- All elements of the result should be positive
prop_sieve_1 :: Test
prop_sieve_1 = randomTest
                 "forall n. all (>0) (sieve n)"
                 1
                 (\n -> all (>0) (sieve n))

-- All elements of the result should be less than the input number
prop_sieve_2 :: Test
prop_sieve_2 = randomTest
                 "forall n. all (<n) (sieve n)"
                 1
                 (\n -> all (<n) (sieve n))

-- The elements should be in increasing order
prop_sieve_3 :: Test
prop_sieve_3 = randomTest
                 "forall n. increasing (sieve n)"
                 1
                 (\n -> increasing (sieve n))
  where
    increasing (x:y:xs) = (x < y) && increasing (y:xs)
    increasing _        = True

-- TODO: Add a test that all of them are actually prime
-- TODO: Add a test that there is no other prime among them?
-- TODO: Add a test that if non-empty then the first element should always be 2?
-- TODO: Add some unti tests too, in order to check some cornercases?

-- * Some more unit tests from the assignment pdf
-- ----------------------------------------------------------------------------

prop_sieve_4 :: Test
prop_sieve_4 = unitTest
                 "sieve 20"
                 (sieve 20)
                 [2,3,5,7,11,13,17,19]

prop_sieve_5 :: Test
prop_sieve_5 = unitTest
                 "sieve 49"
                 (sieve 49)
                 [2,3,5,7,11,13,17,19,23,29,31,37,41,43,47]

-- * Tests for floorSquare
-- ----------------------------------------------------------------------------

-- Squaring the result should be at most the input number
prop_floor_square_1 :: Test
prop_floor_square_1 = randomTest
                        "forall n. (n >= 0) ==> ((floorSquare n ^ 2) <= n)"
                        1
                        (\n -> (n >= 0) ==> ((floorSquare n ^ (2 :: Int)) <= n))

-- The floor square root should be be maximal
prop_floor_square_2 :: Test
prop_floor_square_2 = randomTest
                        "forall n. (n >= 0) ==> (((floorSquare n + 1) ^ 2) > n)"
                        1
                        (\n -> (n >= 0) ==> (((floorSquare n + 1) ^ (2 :: Int)) > n))

-- * Tests for fastSieve
-- ----------------------------------------------------------------------------

-- The fast function should behave have exactly the same results as the slow one
prop_fast_sieve_1 :: Test
prop_fast_sieve_1 = randomTest
                      "forall n. sieve n == fastSieve n"
                      1
                      (\n -> sieve n == fastSieve n)

-- All the tests to run
allTests :: [Test]
allTests = [ -- * Function sieve
             -- --------------------------------------------------------------------------
             prop_sieve_1, prop_sieve_2, prop_sieve_3
           , prop_sieve_4, prop_sieve_5

             -- * Function floorSquare
             -- --------------------------------------------------------------------------
           , prop_floor_square_1, prop_floor_square_2

             -- * Function fastSieve
             -- --------------------------------------------------------------------------
           , prop_fast_sieve_1

           ]

-- Default call
main :: IO ()
main = processSubmission allTests

-- -- Uncomment this if you want to check the tests locally, without colors
-- main :: IO ()
-- main = runAndPrintTestsLocally False allTests

-- -- Uncomment this if you want to check the tests locally, with colors enabled
-- main :: IO ()
-- main = runAndPrintTestsLocally True allTests

