
module Main (main) where

import Template
import Testing

allTests :: [Test]
allTests = [
             ----- Part "First Folds" -----
             -- checks for length'
             unitTest "length' [] = 0"
                      (length' [])
                      0
           , unitTest "length' [1] = 1"
                      (length' [1])
                      1
           , unitTest "length' [1..10] = 10"
                      (length' [1..10])
                      10

             -- checks for any'
           , unitTest "any' (>1) [] = False"
                      (any' (>1) [])
                      False
           , unitTest "any' (>1) [1] = False"
                      (any' (>1) [1])
                      False
           , unitTest "any' (>1) [2] = True"
                      (any' (>1) [2])
                      True
           , unitTest "any' (>1) [1, 2] = True"
                      (any' (>1) [1, 2])
                      True
           , unitTest "any' (>1) [2, 1] = True"
                      (any' (>1) [2, 1])
                      True

             -- checks for all'
           , unitTest "all' (>1) [] = True"
                      (all' (>1) [])
                      True
           , unitTest "all' (>1) [1] = False"
                      (all' (>1) [1])
                      False
           , unitTest "all' (>1) [2] = True"
                      (all' (>1) [2])
                      True
           , unitTest "all' (>1) [1, 2] = False"
                      (all' (>1) [1, 2])
                      False
           , unitTest "all' (>1) [2, 1] = False"
                      (all' (>1) [2, 1])
                      False
           , unitTest "all' (>1) [2, 3] = True"
                      (all' (>1) [2, 3])
                      True

             -- checks for map'
           , unitTest "map' (+1) [] = []"
                      (map' (+1) [])
                      []
           , unitTest "map' (+1) [1] = [2]"
                      (map' (+1) [1])
                      [2]
           , unitTest "map' (+1) $ map' (+1) [1] = [3]"
                      (map' (+1) $ map' (+1) [1])
                      [3]

             -- checks for filter'
           , unitTest "filter' (\\_ -> True) [] = []"
                      (filter' (\_ -> True) [])
                      []
           , unitTest "filter' (\\_ -> False) [] = []"
                      (filter' (\_ -> False) [])
                      []
           , unitTest "filter' (>1) [1, 2] = [2]"
                      (filter' (>1) [1, 2])
                      [2]
           , unitTest "filter' (>1) [2, 1] = [2]"
                      (filter' (>1) [2, 1])
                      [2]
           , unitTest "filter' (\\_ -> True) [1..10] = [1..10]"
                      (filter' (\_ -> True) [1..10])
                      [1..10]
           , unitTest "filter' (\\_ -> False) [1..10] = []"
                      (filter' (\_ -> False) [])
                      []

             ----- Part "Beginning Composer" -----
             -- checks for amountEven
           , unitTest "amountEven [] = 0"
                      (amountEven [])
                      0
           , unitTest "amountEven [1] = 0"
                      (amountEven [1])
                      0
           , unitTest "amountEven [2] = 1"
                      (amountEven [2])
                      1
           , unitTest "amountEven [1..10] = 5"
                      (amountEven [1..10])
                      5

             -- checks for onlyOdd
           , unitTest "onlyOdd [] = []"
                      (onlyOdd [])
                      []
           , unitTest "onlyOdd [1] = [1]"
                      (onlyOdd [1])
                      [1]
           , unitTest "onlyOdd [2] = []"
                      (onlyOdd [2])
                      []
           , unitTest "onlyOdd [1..10] = [1,3,5,7,9]"
                      (onlyOdd [1..10])
                      [1,3,5,7,9]

             -- checks for absGtFive
           , unitTest "absGtFive [] = 0"
                      (absGtFive [])
                      0
           , unitTest "absGtFive [10] = 1"
                      (absGtFive [10])
                      1
           , unitTest "absGtFive [-10] = 1"
                      (absGtFive [-10])
                      1
           , unitTest "absGtFive [-10, 3, -3, 10] = 2"
                      (absGtFive [-10, 3, -3, 10])
                      2

             -- checks for anyEvenGtFive
           , unitTest "anyEvenGtFive [] = False"
                      (anyEvenGtFive [])
                      False
           , unitTest "anyEvenGtFive [9] = False"
                      (anyEvenGtFive [9])
                      False
           , unitTest "anyEvenGtFive [10] = True"
                      (anyEvenGtFive [10])
                      True
           , unitTest "anyEvenGtFive [9, 10] = True"
                      (anyEvenGtFive [9, 10])
                      True

             -- checks for anyEvenGtFive'
           , unitTest "anyEvenGtFive' [] = False"
                      (anyEvenGtFive' [])
                      False
           , unitTest "anyEvenGtFive' [9] = False"
                      (anyEvenGtFive' [9])
                      False
           , unitTest "anyEvenGtFive' [10] = True"
                      (anyEvenGtFive' [10])
                      True
           , unitTest "anyEvenGtFive' [9, 10] = True"
                      (anyEvenGtFive' [9, 10])
                      True
           ]

-- Default call
main :: IO ()
main = processSubmission allTests
