
module Template where

foldr' :: (Int -> a -> a) -> a -> [Int] -> a
foldr' f z []       = z
foldr' f z (x : xs) = f x (foldr f z xs)

length' :: [Int] -> Int
length' = error "Not implemented"

any' :: (Int -> Bool) -> [Int] -> Bool
any' = error "Not implemented"

all' :: (Int -> Bool) -> [Int] -> Bool
all' = error "Not implemented"

map' :: (Int -> Int) -> [Int] -> [Int]
map' = error "Not implemented"

filter' :: (Int -> Bool) -> [Int] -> [Int]
filter' = error "Not implemented"

-- * Given helpers

even' :: Int -> Bool
even' = even

not' :: Bool -> Bool
not' = not

absolute' :: Int -> Int
absolute' = abs

greaterThanFive :: Int -> Bool
greaterThanFive x = x > 5

-- * Beginning Composer

amountEven :: [Int] -> Int
amountEven = error "Not implemented"

onlyOdd :: [Int] -> [Int]
onlyOdd = error "Not implemented"

absGtFive :: [Int] -> Int
absGtFive = error "Not implemented"

anyEvenGtFive :: [Int] -> Bool
anyEvenGtFive = error "Not implemented"

anyEvenGtFive' :: [Int] -> Bool
anyEvenGtFive' = error "Not implemented"
