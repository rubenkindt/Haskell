{-# LANGUAGE StandaloneDeriving         #-}
{-# LANGUAGE ScopedTypeVariables        #-}
{-# LANGUAGE NegativeLiterals           #-}
{-# OPTIONS_GHC -Wall                   #-}
{-# OPTIONS_GHC -Wall -fno-warn-orphans #-}

module Main (main) where

import MyHaskell
import Testing

-- Tests
-- ----------------------------------------------------------------------------

prop_groupSpawns_1 :: Test
prop_groupSpawns_1 = unitTest
                     "groupSpawnsBy spawnPokemon testSpawns == [(\"Pidgey\", [pidgeySpawn1, pidgeySpawn2]), (\"Pikachu\", [pikachuSpawn])]"
                     (groupSpawnsBy spawnPokemon testSpawns == [("Pidgey", [pidgeySpawn1, pidgeySpawn2]), ("Pikachu", [pikachuSpawn])])
                     True

prop_mostCommon_1 :: Test
prop_mostCommon_1 = unitTest
                    "mostCommonPokemon testSpawns == [(\"Pidgey\", 2), (\"Pikachu\", 1)]"
                    (mostCommonPokemon testSpawns == [("Pidgey", 2), ("Pikachu", 1)])
                    True

prop_topSpawnPoints_1 :: Test
prop_topSpawnPoints_1 = unitTest
                         "topSpawnPointsOf \"Pikachu\" testSpawns == [((50.864605, 4.6786203), 1)]"
                         (topSpawnPointsOf "Pikachu" testSpawns == [((50.864605, 4.6786203), 1)])
                         True

prop_topHours_1 :: Test
prop_topHours_1 = unitTest
                  "topHours testSpawns == [(12, 2), (3, 1)]"
                  (topHours testSpawns == [(12, 2), (3, 1)])
                  True

prop_topWeekDays_1 :: Test
prop_topWeekDays_1 = unitTest
                     "topWeekDays testSpawns == [(Friday, 2), (Tuesday, 1)]"
                     (topWeekDays testSpawns == [(Friday, 2), (Tuesday, 1)])
                     True

prop_dayAndNight_1 :: Test
prop_dayAndNight_1 = unitTest
                     "dayAndNight testSpawns == (2,1)"
                     (dayAndNight testSpawns == (2,1))
                     True

prop_aroundTheHours_1 :: Test
prop_aroundTheHours_1 = unitTest
                        "aroundTheHours testSpawns == (2,1)"
                        (aroundTheHours testSpawns == (2,1))
                        True



-- All the tests to run
allTests :: [Test]
allTests = [ prop_groupSpawns_1
           , prop_mostCommon_1
           , prop_topSpawnPoints_1
           , prop_topHours_1
           , prop_topWeekDays_1
           , prop_dayAndNight_1
           , prop_aroundTheHours_1
           ]


-- Default call
main :: IO ()
main = processSubmission allTests

-- -- Uncomment this if you want to check the tests locally, without colors
-- main :: IO ()
-- main = runAndPrintTestsLocally False allTests

-- -- Uncomment this if you want to check the tests locally, with colors enabled
-- main :: IO ()
-- main = runAndPrintTestsLocally True allTests

