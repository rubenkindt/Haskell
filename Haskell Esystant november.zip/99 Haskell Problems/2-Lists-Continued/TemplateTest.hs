{-# LANGUAGE StandaloneDeriving  #-}
{-# LANGUAGE ScopedTypeVariables #-}

{-# OPTIONS_GHC -Wall #-}

module Main (main) where

import Template
import Testing

import Data.List (isInfixOf)

-- * Tests for decode
-- ----------------------------------------------------------------------------

-- The frequencies should add up to the length of the result
prop_decode_1 :: Test
prop_decode_1 = randomTest
                  "forall n xs. (n >= 0) ==> (n * length xs == length (decode (zip (repeat n) xs)))"
                  2
                  (\n (xs :: [Int]) -> (n >= 0) ==> (n * length xs == length (decode (zip (repeat n) xs))))

-- A unit test from the assignment
prop_decode_2 :: Test
prop_decode_2 = unitTest
                  "decode [(4,\'a\'),(1,\'b\'),(2,\'c\'),(2,\'a\'),(1,\'d\'),(4,\'e\')]"
                  (decode [(4,'a'),(1,'b'),(2,'c'),(2,'a'),(1,'d'),(4,'e')])
                  "aaaabccaadeeee"

-- TODO: Add more random tests?

-- * Tests for dupli
-- ----------------------------------------------------------------------------

-- The length of the resulting list should be twice the original
prop_dupli_1 :: Test
prop_dupli_1 = randomTest
                 "forall xs. length (dupli xs) == 2 * length xs"
                 1
                 (\(xs :: [Int]) -> length (dupli xs) == 2 * length xs)

-- Element in original position n should be found in position (2*n)
prop_dupli_2 :: Test
prop_dupli_2 = randomTest
                 "forall n xs. (n < length xs && n >= 0) ==> ((xs !! n) == (dupli xs !! (2*n)))"
                 2
                 (\n (xs :: [Int]) -> (n < length xs && n >= 0) ==> ((xs !! n) == (dupli xs !! (2*n))))

-- Element in original position n should be found in position (2*n+1)
prop_dupli_3 :: Test
prop_dupli_3 = randomTest
                 "forall n xs. (n < length xs && n >= 0) ==> ((xs !! n) == (dupli xs !! (2*n)))"
                 2
                 (\n (xs :: [Int]) -> (n < length xs && n >= 0) ==> ((xs !! n) == (dupli xs !! (2*n+1))))

-- A unit test from the assignment
prop_dupli_4 :: Test
prop_dupli_4 = unitTest
                 "dupli [1,2,3]"
                 (dupli [1,2,3 :: Integer])
                 [1,1,2,2,3,3]

-- * Tests for repli
-- ----------------------------------------------------------------------------

-- The length of the resulting list should be n times the original
prop_repli_1 :: Test
prop_repli_1 = randomTest
                 "forall xs n. (n >= 0) ==> (length (repli xs n) == n * length xs)"
                 2
                 (\(xs :: [Int]) n -> (n >= 0) ==> (length (repli xs n) == n * length xs))

-- Element in original position k should be found in position (n*k)
prop_repli_2 :: Test
prop_repli_2 = randomTest
                 "forall k xs n. (k < length xs && k >= 0 && n > 0 && n <= 100) ==> ((xs !! k) == (repli xs n !! (n*k)))"
                 3
                 (\k (xs :: [Int]) n -> (k < length xs && k >= 0 && n > 0 && n <= 100) ==> ((xs !! k) == (repli xs n !! (n*k))))

-- Replication with zero should result in the empty list
prop_repli_3 :: Test
prop_repli_3 = randomTest
                 "forall xs. repli xs 0 == []"
                 1
                 (\(xs :: [Bool]) -> repli xs 0 == [])

-- A unit test from the assignment
prop_repli_4 :: Test
prop_repli_4 = unitTest
                 "repli \"abc\" 3"
                 (repli "abc" 3)
                 "aaabbbccc"

-- * Tests for dropEvery
-- ----------------------------------------------------------------------------

-- The length L of the list should reduce to L - (L `div` n)
prop_drop_every_1 :: Test
prop_drop_every_1 = randomTest
                      "forall xs n. (n > 0) ==> (length (dropEvery xs n) == length xs - (length xs `div` n))"
                      2
                      (\(xs :: [Bool]) n -> (n > 0) ==> (length (dropEvery xs n) == length xs - (length xs `div` n)))

-- -- If the function is called with a non-positive number,
-- -- it should return the argument untouched
-- prop_drop_every_2 :: Test
-- prop_drop_every_2 = randomTest
--                       "forall xs n. (n <= 0) ==> (dropEvery xs n == xs)"
--                       2
--                       (\(xs :: [Bool]) n -> (n <= 0) ==> (dropEvery xs n == xs))

-- A unit test from the assignment
prop_drop_every_2 :: Test
prop_drop_every_2 = unitTest
                      "dropEvery \"abcdefghik\" 3"
                      (dropEvery "abcdefghik" 3)
                      "abdeghk"

-- * Tests for split
-- ----------------------------------------------------------------------------

-- No matter where you split, the concatenation
-- of the lists should result in the input list
prop_split_1 :: Test
prop_split_1 = randomTest
                 "forall n xs. (n >= 0 && n <= length xs) ==> fst (split xs n) ++ snd (split xs n) == xs"
                 2
                 (\n (xs :: [Bool]) -> (n >= 0 && n <= length xs) ==> fst (split xs n) ++ snd (split xs n) == xs)

-- The first result should have the length indicated by the argument
prop_split_2 :: Test
prop_split_2 = randomTest
                 "forall n xs. (n >= 0 && n <= length xs) ==> (length (fst (split xs n)) == n)"
                 2
                 (\n (xs :: [Bool]) -> (n >= 0 && n <= length xs) ==> (length (fst (split xs n)) == n))

-- The second argument should have the resulting length
prop_split_3 :: Test
prop_split_3 = randomTest
                 "forall n xs. (n >= 0 && n <= length xs) ==> (length (snd (split xs n)) == length xs - n)"
                 2
                 (\n (xs :: [Bool]) -> (n >= 0 && n <= length xs) ==> (length (snd (split xs n)) == length xs - n))


-- A unit test from the assignment
prop_split_4 :: Test
prop_split_4 = unitTest
                 "split \"abcdefghik\" 3"
                 (split "abcdefghik" 3)
                 ("abc", "defghik")

-- * Tests for slice
-- ----------------------------------------------------------------------------

-- CAREFUL: This is a test that takes some time
-- The slice should be an infix of the original list
prop_slice_1 :: Test
prop_slice_1 = randomTest
                 "forall xs. length xs < 10 ==> all (\\l -> isInfixOf l xs) [ slice xs i j | i <- [1..length xs], j <- [i..length xs]]"
                 1
                 (\(xs :: [Int]) -> length xs < 10 ==> all (\l -> isInfixOf l xs) [ slice xs i j | i <- [1..length xs], j <- [i..length xs]])

-- CAREFUL: This is a test that takes some time
-- The length of the slice should be as much the indices indicate
prop_slice_2 :: Test
prop_slice_2 = randomTest
                 "forall xs. length xs < 10 ==> and [ length (slice xs i j) == j-i+1 | i <- [1..length xs], j <- [i..length xs]]"
                 1
                 (\(xs :: [Int]) -> length xs < 10 ==> and [ length (slice xs i j) == j-i+1 | i <- [1..length xs], j <- [i..length xs]])

-- A unit test from the assignment
prop_slice_3 :: Test
prop_slice_3 = unitTest
                 "slice \"abcdefghijk\" 3 7"
                 (slice "abcdefghijk" 3 7)
                 "cdefg"

-- A unit test from the assignment
prop_slice_4 :: Test
prop_slice_4 = unitTest
                 "slice \"abc\" 3 2"
                 (slice "abc" 3 2)
                 ""

-- * Tests for rotate
-- ----------------------------------------------------------------------------

-- Rotating by the length of the list should be the identity
prop_rotate_1 :: Test
prop_rotate_1 = randomTest
                  "forall xs. rotate xs (length xs) == xs"
                  1
                  (\(xs :: [Int]) -> rotate xs (length xs) == xs)

-- Rotating an empty list has no effect
prop_rotate_2 :: Test
prop_rotate_2 = randomTest
                  "forall n. rotate [] n == []"
                  1
                  (\n -> rotate ([] :: [Bool]) n == [])


-- A unit test from the assignment
prop_rotate_3 :: Test
prop_rotate_3 = unitTest
                  "rotate \"abcdefgh\" 3"
                  (rotate "abcdefgh" 3)
                  "defghabc"

-- A unit test from the assignment
prop_rotate_4 :: Test
prop_rotate_4 = unitTest
                  "rotate \"abcdefgh\" (-2)"
                  (rotate "abcdefgh" (-2))
                  "ghabcdef"

-- * Tests for removeAt
-- ----------------------------------------------------------------------------

-- The length of the resulting list should be L-1
prop_remove_at_1 :: Test
prop_remove_at_1 = randomTest
                     "forall n xs. (n > 1 && n <= length xs) ==> (length (snd (removeAt n xs)) == length xs - 1)"
                     2
                     (\n (xs :: [Bool]) -> (n > 1 && n <= length xs) ==> (length (snd (removeAt n xs)) == length xs - 1))

-- The removed element should be in the exact position asked
prop_remove_at_2 :: Test
prop_remove_at_2 = randomTest
                     "forall n xs. (n > 1 && n <= length xs) ==> (fst (removeAt n xs) == xs !! (n-1))"
                     2
                     (\n (xs :: [Int]) -> (n > 1 && n <= length xs) ==> (fst (removeAt n xs) == xs !! (n-1)))

-- Helper function
insertAt :: Int -> a -> [a] -> [a]
insertAt n x xs
  | n <= 0    = error "out of range"
  | n == 1    = (x:xs)
  | otherwise = case xs of
      []     -> error "out of range"
      (y:ys) -> y : insertAt (n-1) x ys

-- Inserting the element back in should result in the input list
prop_remove_at_3 :: Test
prop_remove_at_3 = randomTest
                     "forall n xs. (n > 1 && n <= length xs) ==> (insertAt n (fst (removeAt n xs)) (snd (removeAt n xs)) == xs)"
                     2
                     (\n (xs :: [Int]) -> (n > 1 && n <= length xs) ==> (insertAt n (fst (removeAt n xs)) (snd (removeAt n xs)) == xs))

-- A unit test from the assignment
prop_remove_at_4 :: Test
prop_remove_at_4 = unitTest
                     "removeAt 2 \"abcd\""
                     (removeAt 2 "abcd")
                     ('b',"acd")

-- All the tests to run
allTests :: [Test]
allTests = [ prop_decode_1, prop_decode_2
           , prop_dupli_1, prop_dupli_2, prop_dupli_3, prop_dupli_4
           , prop_repli_1, prop_repli_2, prop_repli_3, prop_repli_4
           , prop_drop_every_1, prop_drop_every_2 -- , prop_drop_every_3
           , prop_split_1, prop_split_2, prop_split_3, prop_split_4
           , prop_slice_1, prop_slice_2, prop_slice_3, prop_slice_4
           , prop_rotate_1, prop_rotate_2, prop_rotate_3, prop_rotate_4
           , prop_remove_at_1, prop_remove_at_2, prop_remove_at_3, prop_remove_at_4
           ]

-- Default call
main :: IO ()
main = processSubmission allTests

-- -- Uncomment this if you want to check the tests locally, without colors
-- main :: IO ()
-- main = runAndPrintTestsLocally False allTests

-- -- Uncomment this if you want to check the tests locally, with colors enabled
-- main :: IO ()
-- main = runAndPrintTestsLocally True allTests

