
module Template where

-- * Exercise 2: Lists, Continued
-- ----------------------------------------------------------------------------

decode :: [(Int, a)] -> [a]
decode = error "Not implemented"

dupli :: [a] -> [a]
dupli = error "Not implemented"

repli :: [a] -> Int -> [a]
repli = error "Not implemented"

dropEvery :: [a] -> Int -> [a]
dropEvery = error "Not implemented"

split :: [a] -> Int -> ([a], [a])
split = error "Not implemented"

slice :: [a] -> Int -> Int -> [a]
slice = error "Not implemented"

rotate :: [a] -> Int -> [a]
rotate = error "Not implemented"

removeAt :: Int -> [a] -> (a, [a])
removeAt = error "Not implemented"

