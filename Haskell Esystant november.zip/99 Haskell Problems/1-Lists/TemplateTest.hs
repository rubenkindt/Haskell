{-# LANGUAGE StandaloneDeriving  #-}
{-# LANGUAGE ScopedTypeVariables #-}

{-# OPTIONS_GHC -Wall #-}

module Main (main) where

import Template
import Testing

-- * Tests for myLast
-- ----------------------------------------------------------------------------

-- If we append an element at the end, that will be the last
prop_last_1 :: Test
prop_last_1 = randomTest
                "forall x xs. myLast (xs ++ [x]) == x"
                2
                (\x xs -> myLast (xs ++ [x :: Int]) == x)

-- A unit test from the assignment
prop_last_2 :: Test
prop_last_2 = unitTest
                "myLast [1,2,3,4]"
                (myLast [1,2,3,4])
                (4 :: Int)

-- A unit test from the assignment
prop_last_3 :: Test
prop_last_3 = unitTest
                "myLast [\'x\',\'y\',\'z\']"
                (myLast ['x','y','z'])
                'z'

-- * Tests for myButLast
-- ----------------------------------------------------------------------------

-- If we append two elements at the end, the first of them will be the result
prop_but_last_1 :: Test
prop_but_last_1 = randomTest
                    "forall x xs. myLast (xs ++ [x,1]) == x"
                    2
                    (\x xs -> myButLast (xs ++ [x,1 :: Int]) == x)

-- A unit test from the assignment
prop_but_last_2 :: Test
prop_but_last_2 = unitTest
                    "myButLast [1,2,3,4]"
                    (myButLast [1,2,3,4 :: Int])
                    3

-- A unit test from the assignment
prop_but_last_3 :: Test
prop_but_last_3 = unitTest
                    "myButLast [\'a\'..\'z\']"
                    (myButLast ['a'..'z'])
                    'y'

-- * Tests for elementAt
-- ----------------------------------------------------------------------------

-- Collecting the elements of all positions should give the input list
prop_element_at_1 :: Test
prop_element_at_1 = randomTest
                      "forall xs. (map (elementAt xs) [1..length xs] == xs)"
                      1
                      (\(xs :: [Int]) -> (map (elementAt xs) [1..length xs] == xs))

-- A unit test from the assignment
prop_element_at_2 :: Test
prop_element_at_2 = unitTest
                      "elementAt [1,2,3] 2"
                      (elementAt [1,2,3 :: Int] 2)
                      2

-- A unit test from the assignment
prop_element_at_3 :: Test
prop_element_at_3 = unitTest
                      "elementAt \"haskell\" 5"
                      (elementAt "haskell" 5)
                      'e'

-- * Tests for myLength
-- ----------------------------------------------------------------------------

-- The length of the concatenation is the sum of the lengths of two lists
prop_length_1 :: Test
prop_length_1 = randomTest
                  "forall xs ys. myLength xs + myLength ys == myLength (xs ++ ys)"
                  2
                  (\(xs :: [Int]) ys -> myLength xs + myLength ys == myLength (xs ++ ys))

-- A unit test from the assignment
prop_length_2 :: Test
prop_length_2 = unitTest
                  "myLength [123, 456, 789]"
                  (myLength [123, 456, 789 :: Int])
                  3

-- A unit test from the assignment
prop_length_3 :: Test
prop_length_3 = unitTest
                  "myLength \"Hello, world!\""
                  (myLength "Hello, world!")
                  13

-- * Tests for myReverse
-- ----------------------------------------------------------------------------

-- Reversing twice is the identity
prop_reverse_1 :: Test
prop_reverse_1 = randomTest
                   "forall xs. myReverse (myReverse xs) == xs"
                   1
                   (\(xs :: [Int]) -> myReverse (myReverse xs) == xs)

-- A unit test from the assignment
prop_reverse_2 :: Test
prop_reverse_2 = unitTest
                   "myReverse \"A man, a plan, a canal, panama!\""
                   (myReverse "A man, a plan, a canal, panama!")
                   "!amanap ,lanac a ,nalp a ,nam A"

-- A unit test from the assignment
prop_reverse_3 :: Test
prop_reverse_3 = unitTest
                   "myReverse [1,2,3,4]"
                   (myReverse [1,2,3,4])
                   [4,3,2,1 :: Int]

-- * Tests for isPalindrome
-- ----------------------------------------------------------------------------

-- A list is either palindrome or it cannot be read the same way both directions
prop_palindrome_1 :: Test
prop_palindrome_1 = randomTest
                      "forall xs. isPalindrome xs /= (myReverse xs /= xs)"
                      1
                      (\(xs :: [Int]) -> isPalindrome xs /= (myReverse xs /= xs))

-- If you reverse a list and concatenate it to the original, you get a palindrome
prop_palindrome_2 :: Test
prop_palindrome_2 = randomTest
                   "forall xs. isPalindrome (xs ++ myReverse xs)"
                   1
                   (\(xs :: [Int]) -> isPalindrome (xs ++ myReverse xs))

-- A unit test from the assignment
prop_palindrome_3 :: Test
prop_palindrome_3 = unitTest
                      "isPalindrome [1,2,3]"
                      (isPalindrome [1,2,3 :: Int])
                      False

-- A unit test from the assignment
prop_palindrome_4 :: Test
prop_palindrome_4 = unitTest
                      "isPalindrome \"madamimadam\""
                      (isPalindrome "madamimadam")
                      True

-- A unit test from the assignment
prop_palindrome_5 :: Test
prop_palindrome_5 = unitTest
                      "isPalindrome [1,2,4,8,16,8,4,2,1]"
                      (isPalindrome [1,2,4,8,16,8,4,2,1 :: Int])
                      True

-- A unit test from the assignment
prop_palindrome_6 :: Test
prop_palindrome_6 = unitTest
                      "isPalindrome [1,2,2,1]"
                      (isPalindrome [1,2,2,1 :: Int])
                      True

-- * Tests for compress
-- ----------------------------------------------------------------------------

-- The compression of a palindrome gives you a palindrome
prop_compress_1 :: Test
prop_compress_1 = randomTest
                    "forall xs. isPalindrome (compress (xs ++ myReverse xs))"
                    1
                    (\(xs :: [Int]) -> isPalindrome (compress (xs ++ myReverse xs)))

-- Compression is idempotent
prop_compress_2 :: Test
prop_compress_2 = randomTest
                    "forall xs. compress (compress xs) == compress xs"
                    1
                    (\(xs :: [Bool]) -> compress (compress xs) == compress xs)

-- A unit test from the assignment
prop_compress_3 :: Test
prop_compress_3 = unitTest
                    "compress \"aaaabccaadeeee\""
                    (compress "aaaabccaadeeee")
                    "abcade"

-- And one final unit test
prop_compress_4 :: Test
prop_compress_4 = unitTest
                    "length (compress (concatMap (replicate 8) [1..10]))"
                    (length (compress (concatMap (replicate 8) [1..10 :: Int])))
                    10

-- * Tests for pack
-- ----------------------------------------------------------------------------

-- The length of the result should be the same as the length of compression
prop_pack_1 :: Test
prop_pack_1 = randomTest
                "forall xs. length (pack xs) == length (compress xs)"
                1
                (\(xs :: [Bool]) -> length (pack xs) == length (compress xs))

-- Packing is the inverse of concat
prop_pack_2 :: Test
prop_pack_2 = randomTest
                "forall xs. concat (pack xs) == xs"
                1
                (\(xs :: [Bool]) -> concat (pack xs) == xs)

-- A unit test from the assignment
prop_pack_3 :: Test
prop_pack_3 = unitTest
               "pack \"aaaabccaadeeee\""
               (pack "aaaabccaadeeee")
               ["aaaa","b","cc","aa","d","eeee"]

-- MAYBE ADD MORE? I DON'T KNOW

-- * Tests for encode
-- ----------------------------------------------------------------------------

-- Replicating the elements as many times as the frequency suggests should
-- return the original list
prop_encode_1 :: Test
prop_encode_1 = randomTest
                  "forall xs. concatMap (\\(n,x) -> replicate n x) (encode xs) == xs"
                  1
                  (\(xs :: [Bool]) -> concatMap (\(n,x) -> replicate n x) (encode xs) == xs)

-- A unit test from the assignment
prop_encode_2 :: Test
prop_encode_2 = unitTest
                  "encode \"aaaabccaadeeee\""
                  (encode "aaaabccaadeeee")
                  [(4,'a'),(1,'b'),(2,'c'),(2,'a'),(1,'d'),(4,'e')]

-- MAYBE ADD MORE? I DON'T KNOW

-- All the tests to run
allTests :: [Test]
allTests = [ prop_last_1, prop_last_2, prop_last_3
           , prop_but_last_1, prop_but_last_2, prop_but_last_3
           , prop_element_at_1, prop_element_at_2, prop_element_at_3
           , prop_length_1, prop_length_2, prop_length_3
           , prop_reverse_1, prop_reverse_2, prop_reverse_3
           , prop_palindrome_1, prop_palindrome_2, prop_palindrome_3
           , prop_palindrome_4, prop_palindrome_5, prop_palindrome_6
           , prop_compress_1, prop_compress_2, prop_compress_3, prop_compress_4
           , prop_pack_1, prop_pack_2, prop_pack_3
           , prop_encode_1, prop_encode_2
           ]

-- Default call
main :: IO ()
main = processSubmission allTests

-- -- Uncomment this if you want to check the tests locally, without colors
-- main :: IO ()
-- main = runAndPrintTestsLocally False allTests

-- -- Uncomment this if you want to check the tests locally, with colors enabled
-- main :: IO ()
-- main = runAndPrintTestsLocally True allTests

