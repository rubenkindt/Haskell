
module Template where

-- * Exercise 1: Lists
-- ----------------------------------------------------------------------------

myLast :: [a] -> a
myLast = error "Not implemented"

myButLast :: [a] -> a
myButLast = error "Not implemented"

elementAt :: [a] -> Int -> a
elementAt = error "Not implemented"

myLength :: [a] -> Int
myLength = error "Not implemented"

myReverse :: [a] -> [a]
myReverse = error "Not implemented"

isPalindrome :: Eq a => [a] -> Bool
isPalindrome = error "Not implemented"

compress :: Eq a => [a] -> [a]
compress = error "Not implemented"

pack :: Eq a => [a] -> [[a]]
pack = error "Not implemented"

encode :: Eq a => [a] -> [(Int, a)]
encode = error "Not implemented"

