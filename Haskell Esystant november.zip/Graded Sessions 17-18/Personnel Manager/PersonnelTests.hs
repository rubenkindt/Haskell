{-# LANGUAGE StandaloneDeriving          #-}
{-# LANGUAGE ScopedTypeVariables         #-}
{-# OPTIONS_GHC -Wall                    #-}
{-# OPTIONS_GHC -fno-warn-unused-imports #-}
{-# OPTIONS_GHC -fno-warn-orphans        #-}

module Main (main) where

import Personnel
import Testing
import Control.Monad
import Control.Applicative
import Data.Maybe (isJust, isNothing)

-- Tests for Part 1
-- ----------------------------------------------------------------------------

prop_part1c_1 :: Test
prop_part1c_1 = unitTest
                "createEmployee (example_employees !! 0) 1"
                (show $ createEmployee (example_employees !! 0) 1)
                "1 --- Tony --- 5000 euro/month --- 0 hours"

prop_part1c_2 :: Test
prop_part1c_2 = unitTest
                "createEmployee (example_employees !! 1) 2"
                (show $ createEmployee (example_employees !! 1) 2)
                "2 --- Bruce --- 2000 euro/month --- 0 hours"

prop_part1c_3 :: Test
prop_part1c_3 = unitTest
                "createEmployee (example_employees !! 2) 3"
                (show $ createEmployee (example_employees !! 2) 3)
                "3 --- Nick --- 2000 euro/month --- 0 hours --- 0 conflicts"

prop_part1c_4 :: Test
prop_part1c_4 = unitTest
                "createEmployee (example_employees !! 3) 4"
                (show $ createEmployee (example_employees !! 3) 4)
                "4 --- Phil --- 1500 euro/month --- 0 hours --- 0 conflicts"

prop_part1c_5 :: Test
prop_part1c_5 = unitTest
                "createEmployee (example_employees !! 4) 5"
                (show $ createEmployee (example_employees !! 4) 5)
                "5 --- Steve --- 1500 euro/month --- 0 rooms"

prop_part1d_1 :: Test
prop_part1d_1 = unitTest
                "createInitEmployees example_employees"
                (show $ createInitEmployees example_employees)
                "[1 --- Tony --- 5000 euro/month --- 0 hours,2 --- Bruce --- 2000 euro/month --- 0 hours,3 --- Nick --- 2000 euro/month --- 0 hours --- 0 conflicts,4 --- Phil --- 1500 euro/month --- 0 hours --- 0 conflicts,5 --- Steve --- 1500 euro/month --- 0 rooms]"


-- Tests for Part 2
-- ----------------------------------------------------------------------------

prop_part2a_1 :: Test
prop_part2a_1 = unitTest
                "getMatchingPercentage ICT example_requirements (\"Peter\", [\"Haskell\", \"Git\", \"Motivation\"], 1000)"
                (getMatchingPercentage ICT example_requirements ("Peter", ["Haskell", "Git", "Motivation"], 1000))
                66

prop_part2a_2 :: Test
prop_part2a_2 = unitTest
                "getMatchingPercentage HR example_requirements (\"Peter\", [\"Haskell\", \"Git\", \"Motivation\"], 1000)"
                (getMatchingPercentage HR example_requirements ("Peter", ["Haskell", "Git", "Motivation"], 1000))
                0

prop_part2a_3 :: Test
prop_part2a_3 = unitTest
                "getMatchingPercentage Cleaning  example_requirements (\"Peter\", [\"Haskell\", \"Git\", \"Motivation\"], 1000)"
                (getMatchingPercentage Cleaning  example_requirements ("Peter", ["Haskell", "Git", "Motivation"], 1000))
                50

prop_part2b_1 :: Test
prop_part2b_1 = unitTest
                "sortCandidates ICT example_requirements example_candidates"
                (sortCandidates ICT example_requirements example_candidates)
                [("Peter",["Haskell","Git","Motivation"],1000),("MaryJane",["Prolog","Connections","Looks"],1500),("Ben",["Haskell","PeopleSkills","Connections","Experience","Wisdom"],5000),("May",["PeopleSkills","Experience","Motivation"],2000),("Harry",["Connections","Motivation","Money"],8000)]

prop_part2b_2 :: Test
prop_part2b_2 = unitTest
                "sortCandidates HR example_requirements example_candidates"
                (sortCandidates HR example_requirements example_candidates)
                [("Ben",["Haskell","PeopleSkills","Connections","Experience","Wisdom"],5000),("MaryJane",["Prolog","Connections","Looks"],1500),("May",["PeopleSkills","Experience","Motivation"],2000),("Harry",["Connections","Motivation","Money"],8000),("Peter",["Haskell","Git","Motivation"],1000)]

prop_part2b_3 :: Test
prop_part2b_3 = unitTest
                "sortCandidates Cleaning  example_requirements example_candidates"
                (sortCandidates Cleaning  example_requirements example_candidates)
                [("May",["PeopleSkills","Experience","Motivation"],2000),("Peter",["Haskell","Git","Motivation"],1000),("Ben",["Haskell","PeopleSkills","Connections","Experience","Wisdom"],5000),("Harry",["Connections","Motivation","Money"],8000),("MaryJane",["Prolog","Connections","Looks"],1500)]

prop_part2c_1 :: Test
prop_part2c_1 = unitTest
                "hireCandidate ICT 2000 example_requirements example_candidates"
                (hireCandidate ICT 2000 example_requirements example_candidates)
                (Just ("Peter",["Haskell","Git","Motivation"],1000))

prop_part2c_2 :: Test
prop_part2c_2 = unitTest
                "hireCandidate ICT 500 example_requirements example_candidates"
                (hireCandidate ICT 500 example_requirements example_candidates)
                Nothing

prop_part2c_3 :: Test
prop_part2c_3 = unitTest
                "hireCandidate ICT 2000 example_requirements []"
                (hireCandidate ICT 2000 example_requirements [])
                Nothing

prop_part2d_1 :: Test
prop_part2d_1 = unitTest
                "executeHire ICT 2000 example_requirements example_candidates $ createInitEmployees example_employees"
                (show $ executeHire ICT 2000 example_requirements example_candidates $ createInitEmployees example_employees)
                "[1 --- Tony --- 5000 euro/month --- 0 hours,2 --- Bruce --- 2000 euro/month --- 0 hours,3 --- Nick --- 2000 euro/month --- 0 hours --- 0 conflicts,4 --- Phil --- 1500 euro/month --- 0 hours --- 0 conflicts,5 --- Steve --- 1500 euro/month --- 0 rooms,6 --- Peter --- 1000 euro/month --- 0 hours]"

prop_part2d_2 :: Test
prop_part2d_2 = unitTest
                "executeHire ICT 500 example_requirements example_candidates $ createInitEmployees example_employees"
                (show $ executeHire ICT 500 example_requirements example_candidates $ createInitEmployees example_employees)
                "[1 --- Tony --- 5000 euro/month --- 0 hours,2 --- Bruce --- 2000 euro/month --- 0 hours,3 --- Nick --- 2000 euro/month --- 0 hours --- 0 conflicts,4 --- Phil --- 1500 euro/month --- 0 hours --- 0 conflicts,5 --- Steve --- 1500 euro/month --- 0 rooms]"


-- Tests for Part 3
-- ----------------------------------------------------------------------------

prop_part3a_1 :: Test
prop_part3a_1 = unitTest
                "readDepartment \"ICT\""
                (readDepartment "ICT")
                (Just ICT)

prop_part3a_2 :: Test
prop_part3a_2 = unitTest
                "readDepartment \"Kitchen\""
                (readDepartment "Kitchen")
                Nothing


-- All the tests to run
allTests :: [Test]
allTests = [ prop_part1c_1, prop_part1c_2, prop_part1c_3, prop_part1c_4
           , prop_part1c_5, prop_part1d_1
           , prop_part2a_1, prop_part2a_2, prop_part2a_3
           , prop_part2b_1, prop_part2b_2, prop_part2b_3
           , prop_part2c_1, prop_part2c_2, prop_part2c_3
           , prop_part2d_1, prop_part2d_2
           , prop_part3a_1, prop_part3a_2
           ]



-- Default call
main :: IO ()
main = processSubmission allTests

-- -- Uncomment this if you want to check the tests locally, without colors
-- main :: IO ()
-- main = runAndPrintTestsLocally False allTests

-- Uncomment this if you want to check the tests locally, with colors enabled
-- main :: IO ()
-- main = runAndPrintTestsLocally True allTests

