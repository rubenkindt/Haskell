
module Template where

-- * Function Chaining
-- ----------------------------------------------------------------------------

applyAll :: [a -> a] -> a -> a
applyAll = error "Not implemented"

applyTimes :: Int -> (a -> a) -> a -> a
applyTimes = error "Not implemented"

applyMultipleFuncs :: a -> [a -> b] -> [b]
applyMultipleFuncs = error "Not implemented"

