
module Template where

-- * List Comprehensions
-- ----------------------------------------------------------------------------

mapLC :: (a -> b) -> [a] -> [b]
mapLC = error "Not implemented"

filterLC :: (a -> Bool) -> [a] -> [a]
filterLC = error "Not implemented"

