{-# LANGUAGE StandaloneDeriving  #-}
{-# LANGUAGE ScopedTypeVariables #-}

{-# OPTIONS_GHC -Wall #-}

module Main (main) where

import Template
import Testing

import Data.List (genericLength)

-- * Tests for factorial
-- ----------------------------------------------------------------------------

-- A basic divisibility property of the factorial
prop_factorial_1 :: Test
prop_factorial_1 = randomTest
                     "forall n m. ((n > 1) && (m > n)) ==> (div (factorial m) (factorial n) == product [n+1..m])"
                     2
                     (\n m -> ((n > 1) && (m > n)) ==> (div (factorial m) (factorial n) == product [n+1..m]))

-- A basic divisibility property of the factorial
prop_factorial_2 :: Test
prop_factorial_2 = randomTest
                     "forall n m. ((n > 1) && (m > n)) ==> (mod (factorial m) (factorial n) == 0)"
                     2
                     (\n m -> ((n > 1) && (m > n)) ==> (mod (factorial m) (factorial n) == 0))

-- The factorial of all non-positive numbers is 1
prop_factorial_3 :: Test
prop_factorial_3 = randomTest
                     "forall n. (n <= 0) ==> (factorial n == 1)"
                     1
                     (\n -> (n <= 0) ==> (factorial n == 1))

-- * Some more unit tests from the assignment pdf
-- ----------------------------------------------------------------------------


prop_factorial_4 :: Test
prop_factorial_4 = unitTest
                     "factorial 5"
                     (factorial 5)
                     120

prop_factorial_5 :: Test
prop_factorial_5 = unitTest
                     "factorial 0"
                     (factorial 0)
                     1

prop_factorial_6 :: Test
prop_factorial_6 = unitTest
                     "factorial (-10)"
                     (factorial (-10))
                     1

-- * Tests for sumInts
-- ----------------------------------------------------------------------------

-- Both arguments being the same means the result is also the same as them
prop_sum_ints_1 :: Test
prop_sum_ints_1 = randomTest
                    "forall n. sumInts n n == n"
                    1
                    (\n -> sumInts n n == n)

-- If the first argument is bigger than the second then the sum is zero
prop_sum_ints_2 :: Test
prop_sum_ints_2 = randomTest
                    "forall n m. (n > m) ==> (sumInts n m == 0)"
                    2
                    (\n m -> (n > m) ==> (sumInts n m == 0))

-- Gauss' sum
prop_sum_ints_3 :: Test
prop_sum_ints_3 = randomTest
                    "forall n. (n >= 1) ==> (sumInts 1 n == div (n * (n+1)) 2)"
                    1
                    (\n -> (n >= 1) ==> (sumInts 1 n == div (n * (n+1)) 2))

-- * Some more unit tests from the assignment pdf
-- ----------------------------------------------------------------------------

prop_sum_ints_4 :: Test
prop_sum_ints_4 = unitTest
                    "sumInts 3 5"
                    (sumInts 3 5)
                    12

prop_sum_ints_5 :: Test
prop_sum_ints_5 = unitTest
                    "sumInts 5 3"
                    (sumInts 5 3)
                    0

prop_sum_ints_6 :: Test
prop_sum_ints_6 = unitTest
                    "sumInts 5 5"
                    (sumInts 5 5)
                    5

-- * Tests for myRepeat
-- ----------------------------------------------------------------------------

-- Repeating an element less non-positive times results in the empty list
prop_repeat_1 :: Test
prop_repeat_1 = randomTest
                  "forall n m. (n <= 0) ==> (myRepeat n m == [])"
                  2
                  (\n m -> (n <= 0) ==> (myRepeat n m == []))

-- The sum of the elements should be (n * m)
prop_repeat_2 :: Test
prop_repeat_2 = randomTest
                  "forall n m. (n >= 0) ==> sum (myRepeat n m) == n * m"
                  2
                  (\n m -> (n >= 0) ==> sum (myRepeat n m) == n * m)

-- The length of the elements should be n
prop_repeat_3 :: Test
prop_repeat_3 = randomTest
                  "forall n m. (n >= 0) ==> length (myRepeat n m) == n"
                  2
                  (\n m -> (n >= 0) ==> genericLength (myRepeat n m) == n)

-- All the elements of the list should be equal to m
prop_repeat_4 :: Test
prop_repeat_4 = randomTest
                  "forall n m. allEqual m (myRepeat n m) (All elements should be equal to m)"
                  2
                  (\n m -> allEqual m (myRepeat n m))
  where
    allEqual x xs = all (x==) xs

-- * Tests for flatten
-- ----------------------------------------------------------------------------

-- Flattening a singleton list returns the single element it contains
prop_flatten_1 :: Test
prop_flatten_1 = randomTest
                   "forall xs. flatten [xs] == xs"
                   1
                   (\xs -> flatten [xs] == xs)

-- Flattening the empty list gives the empty list
prop_flatten_2 :: Test
prop_flatten_2 = unitTest
                   "flatten [] == []"
                   (flatten [] == [])
                   True

-- Flattening a list of two elements is their concatenation
prop_flatten_3 :: Test
prop_flatten_3 = randomTest
                   "forall xs ys. flatten [xs,ys] == (xs ++ ys)"
                   2
                   (\xs ys -> flatten [xs,ys] == (xs ++ ys))

-- Distributivity of reverse over flattening
prop_flatten_4 :: Test
prop_flatten_4 = randomTest
                   "forall xs. reverse (flatten xs) == flatten (reverse (map reverse xs))"
                   1
                   (\xs -> reverse (flatten xs) == flatten (reverse (map reverse xs)))

-- And a unit test to check that it behaves ok with different lengths
prop_flatten_5 :: Test
prop_flatten_5 = unitTest
                   "flatten [[1,2],[3],[],[4,5,6]]"
                   (flatten [[1,2],[3],[],[4,5,6]])
                   [1,2,3,4,5,6]

-- * Tests for range
-- ----------------------------------------------------------------------------

-- If the first is larger than the second, the result is empty
prop_range_1 :: Test
prop_range_1 = randomTest
                 "forall m n. (m > n) ==> (range m n == [])"
                 2
                 (\m n -> (m > n) ==> (range m n == []))

-- The span of a number with itself is just the number in a singleton list
prop_range_2 :: Test
prop_range_2 = randomTest
                 "forall m. range m m == [m]"
                 1
                 (\m -> range m m == [m])

-- Consecutive elements differ exactly by 1
prop_range_3 :: Test
prop_range_3 = randomTest
                 "forall m n. differOne (range m n) (Consecutive elements differ by 1)"
                 2
                 (\m n -> differOne (range m n))
  where
    differOne (x:y:xs) = (x + 1 == y) && differOne (y:xs)
    differOne _        = True

-- * Tests for removeMultiples
-- ----------------------------------------------------------------------------

-- removeMultiples is idempotent (if you apply to the same list one time or
-- more you get the same result)
prop_multiples_1 :: Test
prop_multiples_1 = randomTest
                     "forall n xs. (n /= 0) ==> removeMultiples n xs == (removeMultiples n (removeMultiples n xs))"
                     2
                     (\n xs -> (n /= 0) ==> removeMultiples n xs == (removeMultiples n (removeMultiples n xs)))

-- No element in the result divides the number whose multiples we removed
prop_multiples_2 :: Test
prop_multiples_2 = randomTest
                     "forall n xs. (n /= 0) ==> all (\\y -> mod y n /= 0) (removeMultiples n xs)"
                     2
                     (\n xs -> (n /= 0) ==> all (\y -> mod y n /= 0) (removeMultiples n xs))

-- The resulting list should be a subsequence of the input list
prop_multiples_3 :: Test
prop_multiples_3 = randomTest
                     "forall n xs. (n /= 0) ==> isSubsequence (removeMultiples n xs) xs"
                     2
                     (\n xs -> (n /= 0) ==> isSubsequence (removeMultiples n xs) xs)

isSubsequence :: Eq a => [a] -> [a] -> Bool
isSubsequence []     _      = True
isSubsequence (_:_)  []     = False
isSubsequence (x:xs) (y:ys) = if x == y then isSubsequence xs ys else isSubsequence (x:xs) ys

-- The sum of the removed elements should divide n
prop_multiples_4 :: Test
prop_multiples_4 = randomTest
                     "forall n xs. (n /= 0) ==> (mod (sum xs - sum (removeMultiples n xs)) n == 0)"
                     2
                     (\n xs -> (n /= 0) ==> (mod (sum xs - sum (removeMultiples n xs)) n == 0))

-- * Some more unit tests from the assignment pdf
-- ----------------------------------------------------------------------------

prop_mixed_1_9 :: Test
prop_mixed_1_9 = unitTest
                   "sum (removeMultiples 3 (range 1 10))"
                   (sum (removeMultiples 3 (range 1 10)))
                   37

-- All the tests to run
allTests :: [Test]
allTests = [ -- * Function factorial
             -- --------------------------------------------------------------------------
             prop_factorial_1, prop_factorial_2, prop_factorial_3
           , prop_factorial_4, prop_factorial_5, prop_factorial_6

             -- * Function sumInts
             -- --------------------------------------------------------------------------
           , prop_sum_ints_1, prop_sum_ints_2, prop_sum_ints_3
           , prop_sum_ints_4, prop_sum_ints_5, prop_sum_ints_6

             -- * Function myRepeat
             -- --------------------------------------------------------------------------
           , prop_repeat_1, prop_repeat_2, prop_repeat_3, prop_repeat_4

             -- * Function flatten
             -- --------------------------------------------------------------------------
           , prop_flatten_1, prop_flatten_2, prop_flatten_3
           , prop_flatten_4, prop_flatten_5

             -- * Function range
             -- --------------------------------------------------------------------------
           , prop_range_1, prop_range_2, prop_range_3

             -- * Function removeMultiples
             -- --------------------------------------------------------------------------
           , prop_multiples_1, prop_multiples_2, prop_multiples_3, prop_multiples_4

             -- * A test that mixes some of the above functions
             -- --------------------------------------------------------------------------
           , prop_mixed_1_9
           ]

-- Default call
main :: IO ()
main = processSubmission allTests

-- -- Uncomment this if you want to check the tests locally, without colors
-- main :: IO ()
-- main = runAndPrintTestsLocally False allTests

-- -- Uncomment this if you want to check the tests locally, with colors enabled
-- main :: IO ()
-- main = runAndPrintTestsLocally True allTests

