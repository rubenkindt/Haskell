
module Template where

-- * Approximating Pi
-- ----------------------------------------------------------------------------

sumf :: [Float] -> Float
sumf = error "Not implemented"

productf :: [Float] -> Float
productf = error "Not implemented"

piSum :: Float -> Float
piSum = error "Not implemented"

piProd :: Float -> Float
piProd = error "Not implemented"

