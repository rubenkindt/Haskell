
module Template where

-- * List Operations
-- ----------------------------------------------------------------------------

myProduct :: [Integer] -> Integer
myProduct = error "Not implemented"

insert :: Int -> [Int] -> [Int]
insert = error "Not implemented"

myLast :: [Int] -> Int
myLast = error "Not implemented"

