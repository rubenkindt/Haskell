{-# LANGUAGE StandaloneDeriving  #-}
{-# LANGUAGE ScopedTypeVariables #-}

{-# OPTIONS_GHC -Wall #-}

module Main (main) where

import Template
import Testing

-- * Tests for myProduct
-- ----------------------------------------------------------------------------

-- The product of a number x repeated n times is x at the power of n
prop_product_1 :: Test
prop_product_1 = randomTest
                   "forall n x. ((n > 0) && (x > 0)) ==> (myProduct (replicate n x) == x ^ n)"
                   2
                   (\n x -> ((n > 0) && (x > 0)) ==> (myProduct (replicate n x) == x ^ n))

-- All elements of the list divide the product
prop_product_2 :: Test
prop_product_2 = randomTest
                   "forall xs. all (==True) [ mod (myProduct xs) x == 0 | x <- xs, x /= 0 ]"
                   1
                   (\xs -> all (==True) [ mod (myProduct xs) x == 0 | x <- xs, x /=0 ])

-- * Some more tests from the assignment pdf
-- ----------------------------------------------------------------------------

prop_product_3 :: Test
prop_product_3 = unitTest
                   "myProduct [1,2,3]"
                   (myProduct [1,2,3])
                   6

prop_product_4 :: Test
prop_product_4 = unitTest
                   "myProduct []"
                   (myProduct [])
                   1

prop_product_5 :: Test
prop_product_5 = unitTest
                   "myProduct [-2,3,-4,5,-6]"
                   (myProduct [-2,3,-4,5,-6])
                   (-720)

-- * Tests for insert
-- ----------------------------------------------------------------------------

-- Inserting an element in an empty list results in a singleton list with it
prop_insert_1 :: Test
prop_insert_1 = randomTest
                  "forall x. insert x [] == [x]"
                  1
                  (\x -> insert x [] == [x])

-- Just a simple identity
prop_insert_2 :: Test
prop_insert_2 = randomTest
                  "forall n. (n > 0) ==> insert (n+1) [1..n] == [1..n+1]"
                  1
                  (\n -> (n > 0) ==> insert (n+1) [1..n] == [1..n+1])

-- All the previous elements are are smaller
prop_insert_3 :: Test
prop_insert_3 = randomTest
                  "forall x xs. takeWhile (<x) (insert x xs) == takeWhile (<x) xs"
                  2
                  (\x xs -> takeWhile (<x) (insert x xs) == takeWhile (<x) xs)

-- Inserting an element into a list increases the length by one
prop_insert_4 :: Test
prop_insert_4 = randomTest
                  "forall x xs. length (insert x xs) == length xs + 1"
                  2
                  (\x xs -> length (insert x xs) == length xs + 1)

-- * Some more tests from the assignment pdf
-- ----------------------------------------------------------------------------

prop_insert_5 :: Test
prop_insert_5 = unitTest
                  "insert 0 [1,2,3]"
                  (insert 0 [1,2,3])
                  [0,1,2,3]

prop_insert_6 :: Test
prop_insert_6 = unitTest
                  "insert 2 [1,0,3]"
                  (insert 2 [1,0,3])
                  [1,0,2,3]

prop_insert_7 :: Test
prop_insert_7 = unitTest
                  "insert 4 [1,2,3]"
                  (insert 4 [1,2,3])
                  [1,2,3,4]

-- * Tests for myLast
-- ----------------------------------------------------------------------------

-- Appending an element to the end makes it the last
prop_last_1 :: Test
prop_last_1 = randomTest
                "forall x xs. myLast (xs ++ [x]) == x"
                2
                (\x xs -> myLast (xs ++ [x]) == x)


-- * Some more tests from the assignment pdf
-- ----------------------------------------------------------------------------

prop_last_2 :: Test
prop_last_2 = unitTest
                "myLast [1,2,3,4,5]"
                (myLast [1,2,3,4,5])
                5

-- ----------------------------------------------------------------------------

-- All the tests to run
allTests :: [Test]
allTests = [
             -- * Function myProduct
             -- --------------------------------------------------------------------------
             prop_product_1, prop_product_2, prop_product_3
           , prop_product_4, prop_product_5

             -- * Function insert
             -- --------------------------------------------------------------------------
           , prop_insert_1, prop_insert_2, prop_insert_3
           , prop_insert_4, prop_insert_5, prop_insert_6
           , prop_insert_7

             -- * Function last
             -- --------------------------------------------------------------------------
           , prop_last_1, prop_last_2
           ]


           -- Default call
main :: IO ()
main = processSubmission allTests

-- -- Uncomment this if you want to check the tests locally, without colors
-- main :: IO ()
-- main = runAndPrintTestsLocally False allTests

-- -- Uncomment this if you want to check the tests locally, with colors enabled
-- main :: IO ()
-- main = runAndPrintTestsLocally True allTests
